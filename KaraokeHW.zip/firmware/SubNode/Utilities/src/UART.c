#include "UART.h"
#include "Output.h"
#include "VTimer.h"

#define RX_BUFFER_SIZE 50
volatile uint8_t rx_wr_index,rx_rd_index,rx_counter;
uint8_t rx_buffer[RX_BUFFER_SIZE];
uint8_t VTimer_UARTSendByteID = 0;

void UART_InitController(uint32_t _baudrate){
	UART1_DeInit();
	CLK_PeripheralClockConfig(CLK_PERIPHERAL_UART1,ENABLE);
	UART1_Init((uint32_t)_baudrate, UART1_WORDLENGTH_8D, UART1_STOPBITS_1, UART1_PARITY_NO,
		UART1_SYNCMODE_CLOCK_DISABLE, UART1_MODE_TXRX_ENABLE);	
	UART1_ITConfig(UART1_IT_RXNE_OR,ENABLE);
	UART1_Cmd(ENABLE);
	VTimer_UARTSendByteID = VTimerGetID();
}

void UART_SendByte(uint8_t c)
{
	UART1_SendData8(c);
	VTimerSet(VTimer_UARTSendByteID,10);
	/* Loop until the end of transmission */
	while (UART1_GetFlagStatus(UART1_FLAG_TC) == RESET){
		if (VTimerIsFired(VTimer_UARTSendByteID)){
			break;
		}
	}
}

void UART_SendChar(char c){
	UART1_SendData8(c);
	while (UART1_GetFlagStatus(UART1_FLAG_TC) == RESET);
}

void UART_SendString(uint8_t *data_buff){
	while(*data_buff != '\t'){
		UART_SendByte(*data_buff);
		data_buff++;
	}
}
void UART_SendStringLength(uint8_t* data_buff, uint8_t _length){
	uint8_t i=0;
	for (i=0; i<_length; i++)
	{
		UART_SendByte(*data_buff);
		data_buff++;
	}
}

void UART_Receive_ISR(void){
	if(UART1_GetITStatus(UART1_IT_RXNE) != RESET){		
		rx_buffer[rx_wr_index] =  UART1_ReceiveData8();
		if (++rx_wr_index == RX_BUFFER_SIZE) rx_wr_index = 0;
		if (++rx_counter == RX_BUFFER_SIZE)
		{
			rx_counter = 0;
		}		
	}
	UART1_ClearITPendingBit(UART1_IT_RXNE);
	
}

void UART_SendNumber(uint32_t value, uint8_t num_digit)
{
	if(num_digit > 8)
		num_digit = 8;
	switch(num_digit){
		case 8:	UART_SendByte((value/10000000) + 0x30);
		case 7:	UART_SendByte(((value%10000000)/1000000) + 0x30);
		case 6:	UART_SendByte(((value%1000000)/100000) + 0x30);
		case 5:	UART_SendByte(((value%100000)/10000) + 0x30);
		case 4:	UART_SendByte(((value%10000)/1000) + 0x30);
		case 3:	UART_SendByte(((value%1000)/100) + 0x30);
		case 2:	UART_SendByte(((value%100)/10) + 0x30);
		case 1:	UART_SendByte((value%10) + 0x30);
		default: break;
	}
} 

uint8_t UART_ReceiveByte(void){
	uint8_t data;
	if  (rx_counter > 0){
		data=rx_buffer[rx_rd_index];
		if (++rx_rd_index == RX_BUFFER_SIZE) rx_rd_index=0;
		rx_counter--;
	}	
	return data;
}

uint8_t UART_DataAvailable(void){
	return rx_counter;
}

void UART_ClearRxBuffer(void){
	uint8_t index;
	for (index=0;index<RX_BUFFER_SIZE;index++){
		rx_buffer[index] = 0;
	}
	rx_wr_index = 0;
	rx_rd_index = 0;
	rx_counter = 0;	
}
