 #include "Input.h"

uint8_t InputValue[4] = {0,0,0,0};
 void InputInitController(){
	GPIO_Init(DIPSW1_PORT, DIPSW1_PIN, GPIO_MODE_IN_FL_NO_IT);	
	GPIO_Init(DIPSW2_PORT, DIPSW2_PIN, GPIO_MODE_IN_FL_NO_IT);	
	GPIO_Init(DIPSW3_PORT, DIPSW3_PIN, GPIO_MODE_IN_FL_NO_IT);	
	GPIO_Init(DIPSW4_PORT, DIPSW4_PIN, GPIO_MODE_IN_FL_NO_IT);	
	GPIO_Init(DIPSW5_PORT, DIPSW5_PIN, GPIO_MODE_IN_FL_NO_IT);	
	GPIO_Init(DIPSW6_PORT, DIPSW6_PIN, GPIO_MODE_IN_FL_NO_IT);	
	GPIO_Init(DIPSW7_PORT, DIPSW7_PIN, GPIO_MODE_IN_FL_NO_IT);	
	GPIO_Init(DIPSW8_PORT, DIPSW8_PIN, GPIO_MODE_IN_FL_NO_IT);		
}

uint8_t timer_cnt = 0;
void InputService(){
	if (timer_cnt > 10){
		if (GPIO_ReadInputPin(DIPSW1_PORT,DIPSW1_PIN) == 0x00){				
                        InputValue[3] &= ~DIPSW1_MASK;
                }
                else {				
                        InputValue[3] |= DIPSW1_MASK;
                }

		if (GPIO_ReadInputPin(DIPSW2_PORT,DIPSW2_PIN) == 0x00){				
                        InputValue[3] &= ~DIPSW2_MASK;
                }
                else {				
                        InputValue[3] |= DIPSW2_MASK;
                }

		if (GPIO_ReadInputPin(DIPSW3_PORT,DIPSW3_PIN) == 0x00){				
                        InputValue[3] &= ~DIPSW3_MASK;
                }
                else {				
                        InputValue[3] |= DIPSW3_MASK;
                }

		if (GPIO_ReadInputPin(DIPSW4_PORT,DIPSW4_PIN) == 0x00){				
                        InputValue[3] &= ~DIPSW4_MASK;
                }
                else {				
                        InputValue[3] |= DIPSW4_MASK;
                }
		
		if (GPIO_ReadInputPin(DIPSW5_PORT,DIPSW5_PIN) == 0x00){				
                        InputValue[3] &= ~DIPSW5_MASK;
                }
                else {				
                        InputValue[3] |= DIPSW5_MASK;
                }

		if (GPIO_ReadInputPin(DIPSW6_PORT,DIPSW6_PIN) == 0x00){				
                        InputValue[3] &= ~DIPSW6_MASK;
                }
                else {				
                        InputValue[3] |= DIPSW6_MASK;
                }

		if (GPIO_ReadInputPin(DIPSW7_PORT,DIPSW7_PIN) == 0x00){				
                        InputValue[3] &= ~DIPSW7_MASK;
                }
                else {				
                        InputValue[3] |= DIPSW7_MASK;
                }

		if (GPIO_ReadInputPin(DIPSW8_PORT,DIPSW8_PIN) == 0x00){				
                        InputValue[3] &= ~DIPSW8_MASK;
                }
                else {				
                        InputValue[3] |= DIPSW8_MASK;
                }

	        InputValue[1] = InputValue[2];
	        InputValue[2] = InputValue[3];
	        if ((InputValue[1] == InputValue[2])&&(InputValue[2] == InputValue[3])){
			InputValue[0] = InputValue[3];
	        }	
	        timer_cnt = 0;
	}
	else {
		timer_cnt ++;
	}
}


uint8_t GetDipSWValue(){
	return InputValue[0] ;
}

