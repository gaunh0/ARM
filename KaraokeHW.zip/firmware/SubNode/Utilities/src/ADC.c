
#include "ADC.h"
uint16_t ADCValue[ADC_CHANNEL] = {0,0};
uint16_t ADCValueMax[ADC_CHANNEL]= {0,0};

void ADCInitController(){
	 /*  Init GPIO for ADC1 */
	GPIO_Init(GPIOD, GPIO_PIN_2, GPIO_MODE_IN_FL_NO_IT);
	GPIO_Init(GPIOD, GPIO_PIN_3, GPIO_MODE_IN_FL_NO_IT);
	/* De-Init ADC peripheral*/
	ADC1_DeInit();
	/* Init ADC2 peripheral */
	ADC1_Init(ADC1_CONVERSIONMODE_CONTINUOUS, ADC1_CHANNEL_3, ADC1_PRESSEL_FCPU_D2, \
	        ADC1_EXTTRIG_TIM, DISABLE, ADC1_ALIGN_RIGHT, ADC1_SCHMITTTRIG_CHANNEL3,\
	        DISABLE);
	ADC1_Init(ADC1_CONVERSIONMODE_CONTINUOUS, ADC1_CHANNEL_4, ADC1_PRESSEL_FCPU_D2, \
	        ADC1_EXTTRIG_TIM, DISABLE, ADC1_ALIGN_RIGHT, ADC1_SCHMITTTRIG_CHANNEL4,\
	       DISABLE);
	/* Enable EOC interrupt */
	ADC1_ITConfig(ADC1_IT_EOCIE,DISABLE);
	//ADC1_ScanModeCmd(ENABLE);
	ADC1_DataBufferCmd(ENABLE);
	/*Start Conversion */
	ADC1_StartConversion();
	
}

void EnableADCChannel(ADC1_Channel_TypeDef _channel,ADC1_SchmittTrigg_TypeDef _ch){
	ADC1_Init(ADC1_CONVERSIONMODE_CONTINUOUS, _channel, ADC1_PRESSEL_FCPU_D8, \
	        ADC1_EXTTRIG_TIM, DISABLE, ADC1_ALIGN_RIGHT, _ch,\
	        DISABLE);
}
uint8_t adccnt = 0;
uint8_t GetADCState = 0;
void ReadADCValue(){	
	if (adccnt > 5){
		switch (GetADCState){
			case 0:
			//	if (ADC1_GetFlagStatus(ADC1_FLAG_OVR)){		
					ADCValue[0]  = ADC1_GetBufferValue(3);
					if (ADCValue[0] > ADCValueMax[0]){
						ADCValueMax[0] = ADCValue[0];
					}
					GetADCState = 1;				
			//		ADC1_ClearFlag(ADC1_FLAG_OVR);
					EnableADCChannel(ADC1_CHANNEL_4,ADC1_SCHMITTTRIG_CHANNEL4);
			//	}
				break;
			case 1:
			//	if (ADC1_GetFlagStatus(ADC1_FLAG_OVR)){		
					ADCValue[1]  = ADC1_GetBufferValue(4);
					if (ADCValue[1] > ADCValueMax[1]){
						ADCValueMax[1] = ADCValue[1];
					}
					GetADCState = 0;				
			//		ADC1_ClearFlag(ADC1_FLAG_OVR);
					EnableADCChannel(ADC1_CHANNEL_3,ADC1_SCHMITTTRIG_CHANNEL3);
			//	}
				break;
			default:
				GetADCState = 0;
				break;
		}
		adccnt = 0;
	}
	else adccnt++;
}

uint16_t GetADCValue(uint8_t channel){
	return ADCValue[channel];
}
uint16_t GetADCValueMax(uint8_t channel){
	return ADCValueMax[channel];

}
void ClearADCValueMax(){
	ADCValueMax[0] = 0;
	ADCValueMax[1] = 0;
}

