#include "SoftPWM.h"
  
unsigned char softcount=0xFF;
//! global buffers
volatile uint8_t compare[LEDn];
volatile uint8_t compbuff[LEDn];
static Led_TypeDef led_channel_scan = LED0;
volatile uint8_t index=0;

void SoftPWMInitController(){
	for(index=0 ;index<LEDn ; index++)      // initialize all channels
	{
		compare[index] =  0;           // set default PWM values
		compbuff[index] = 0;          // set default PWM values
	}	
}

void SoftPWMService(){
	softcount++;
	softcount = softcount % 101;
	if(softcount == 0){         // increment modulo 101 counter and update
		// the compare values only when counter = 0.
		for (led_channel_scan=LED0;led_channel_scan<LEDn;led_channel_scan++){
			compare[led_channel_scan] = compbuff[led_channel_scan];
			if (compbuff[led_channel_scan] != 0){				
				LEDOn(led_channel_scan);
			}
			else LEDOff(led_channel_scan);
		}
	}
	// clear port pin on compare match (executed on next interrupt)
	for (led_channel_scan=LED0;led_channel_scan<LEDn;led_channel_scan++){		
		if(compare[led_channel_scan] == softcount && compare[led_channel_scan] !=MAX_PWM)
		LEDOff(led_channel_scan);
	}
}

void LEDDimmer(uint8_t led,uint8_t _value){
	if (_value>=100) _value = 100;
	compbuff[led] = _value;
}


