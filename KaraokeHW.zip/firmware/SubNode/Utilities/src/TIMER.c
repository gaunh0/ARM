#include "TIMER.h"

void TimerInitController(){
	TIM4_InitController();
	VTimer_InitController();
}

void TIM4_InitController()
{
	CLK_PeripheralClockConfig(CLK_PERIPHERAL_TIMER4,ENABLE);
	TIM4_TimeBaseInit(TIM4_PRESCALER_128, TIM4_PERIOD);
	/* Clear TIM4 update flag */
	TIM4_ClearFlag(TIM4_FLAG_UPDATE);
	/* Enable update interrupt */
	TIM4_ITConfig(TIM4_IT_UPDATE, ENABLE);
	/* Enable TIM4 */
	TIM4_Cmd(ENABLE);
}


