#include "Output.h"

void OutputInitController(){
	GPIO_Init(RELAY1_PORT, RELAY1_PIN, GPIO_MODE_OUT_PP_LOW_FAST);
	GPIO_Init(RELAY2_PORT, RELAY2_PIN, GPIO_MODE_OUT_PP_LOW_FAST);
	GPIO_Init(LED_PORT, LED_PIN, GPIO_MODE_OUT_PP_LOW_FAST);
}


void Relay1High(){
	GPIO_WriteHigh(RELAY1_PORT,RELAY1_PIN) ; 
}
void Relay1Low(){
	GPIO_WriteLow(RELAY1_PORT,RELAY1_PIN); 
}
void Relay2High(){
	GPIO_WriteHigh(RELAY2_PORT,RELAY2_PIN) ; 
}
void Relay2Low(){
	GPIO_WriteLow(RELAY2_PORT,RELAY2_PIN); 
}

void LedOn(){
	GPIO_WriteLow(LED_PORT,LED_PIN) ; 
}
void LedOff(){
	GPIO_WriteHigh(LED_PORT,LED_PIN) ; 
}
void LedToggle(){
	GPIO_WriteReverse(LED_PORT,LED_PIN) ;
}



