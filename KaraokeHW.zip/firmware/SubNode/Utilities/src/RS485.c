#include "RS485.h"
#include "UART.h"

void RS485InitController(){
       GPIO_Init(RW_PORT, RW_PIN, GPIO_MODE_OUT_PP_LOW_FAST);	
	RS485Receive();
	UART_InitController(115200);
	
}

void RS485Transmit(){
	GPIO_WriteHigh(RW_PORT,RW_PIN) ; 
}
void RS485Receive(){
	GPIO_WriteLow(RW_PORT,RW_PIN) ; 
}

void RS485SendByte(uint8_t c)
{
	UART1_SendData8(c);
	/* Loop until the end of transmission */
	while (UART1_GetFlagStatus(UART1_FLAG_TC) == RESET);
}

void RS485SendChar(char c){
	UART1_SendData8(c);
	while (UART1_GetFlagStatus(UART1_FLAG_TC) == RESET);
}

void RS485SendString(uint8_t *data_buff){
	while(*data_buff != '\t'){
		RS485SendByte(*data_buff);
		data_buff++;
	}
}
void RS485SendStringLength(uint8_t* data_buff, uint8_t _length){
	uint8_t i=0;
	for (i=0; i<_length; i++)
	{
		RS485SendByte(*data_buff);
		data_buff++;
	}
}

void RS485SendNumber(uint32_t value, uint8_t num_digit)
{
	if(num_digit > 8)
		num_digit = 8;
	switch(num_digit){
		case 8:	RS485SendByte((value/10000000) + 0x30);
		case 7:	RS485SendByte(((value%10000000)/1000000) + 0x30);
		case 6:	RS485SendByte(((value%1000000)/100000) + 0x30);
		case 5:	RS485SendByte(((value%100000)/10000) + 0x30);
		case 4:	RS485SendByte(((value%10000)/1000) + 0x30);
		case 3:	RS485SendByte(((value%1000)/100) + 0x30);
		case 2:	RS485SendByte(((value%100)/10) + 0x30);
		case 1:	RS485SendByte((value%10) + 0x30);
		default: break;
	}
} 

uint8_t RS485DataAvailable(){
	return UART_DataAvailable();
}
uint8_t RS485_ReceiveByte(){
	return UART_ReceiveByte();
}

