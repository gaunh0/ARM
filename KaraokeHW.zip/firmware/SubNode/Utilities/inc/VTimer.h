#ifndef	__VTIMER_H__
#define __VTIMER_H__

#include "stm8s.h"

/*============================*/
/* Constant setting           */
/*============================*/

#define NUMBER_OF_VIR_TIMER 		6

void VTimer_InitController();
unsigned char VTimerIsFired(unsigned char timerId);
void VTimerService();
unsigned char VTimerSet(uint8_t timerId,uint32_t period);
unsigned char VTimerGetID();
void VTimerRelease(unsigned char timerId);
void DelayMs(uint16_t period);

#endif

/****************END FILE**************/


