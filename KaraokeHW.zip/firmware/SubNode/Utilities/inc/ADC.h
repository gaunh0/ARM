#ifndef ADC_H
#define ADC_H

#include "stm8s.h"
#include "Config.h"


void ADCInitController();
void ReadADCValue();
uint16_t GetADCValue(uint8_t channel);
uint16_t GetADCValueMax(uint8_t channel);
void ClearADCValueMax();
void ADC1_ISR();
#endif

