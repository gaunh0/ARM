#ifndef TIMER_H
#define TIMER_H


#include "stm8s_tim2.h"
#include "stm8s_tim4.h"
#include "VTimer.h"

#define TIM2_PERIOD       399
#define TIM4_PERIOD       124

void TimerInitController();
void TIM2_InitController();
void TIM4_InitController();

#endif

