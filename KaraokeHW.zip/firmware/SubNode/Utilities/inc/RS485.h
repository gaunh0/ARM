#ifndef RS485_H
#define RS485_H

#include "stm8s.h"

#define RW_PORT            	GPIOD
#define RW_PIN             		GPIO_PIN_4

void RS485InitController();
void RS485Transmit();
void RS485Receive();
void RS485SendByte(uint8_t c);
void RS485SendChar(char c);
void RS485SendString(uint8_t *data_buff);
void RS485SendStringLength(uint8_t* data_buff, uint8_t _length);
void RS485SendNumber(uint32_t value, uint8_t num_digit);
uint8_t RS485DataAvailable();
uint8_t RS485_ReceiveByte();
	
#endif
