#ifndef _INPUT_H
#define _INPUT_H

#include "stm8s.h"

#define DIPSW1_PORT		GPIOC
#define DIPSW1_PIN             	GPIO_PIN_7
#define DIPSW2_PORT		GPIOC
#define DIPSW2_PIN             	GPIO_PIN_6
#define DIPSW3_PORT		GPIOC
#define DIPSW3_PIN		GPIO_PIN_5
#define DIPSW4_PORT		GPIOB
#define DIPSW4_PIN		GPIO_PIN_4
#define DIPSW5_PORT		GPIOB
#define DIPSW5_PIN		GPIO_PIN_5
#define DIPSW6_PORT		GPIOA
#define DIPSW6_PIN		GPIO_PIN_1
#define DIPSW7_PORT		GPIOA
#define DIPSW7_PIN		GPIO_PIN_2
#define DIPSW8_PORT		GPIOA
#define DIPSW8_PIN		GPIO_PIN_3

#define DIPSW1_MASK		0x01
#define DIPSW2_MASK		0x02
#define DIPSW3_MASK		0x04
#define DIPSW4_MASK		0x08
#define DIPSW5_MASK		0x10
#define DIPSW6_MASK		0x20
#define DIPSW7_MASK		0x40
#define DIPSW8_MASK		0x80


#define HIGH_STATE		1
#define LOW_STATE		0

void InputInitController();
void InputService();
uint8_t GetDipSWValue();

#endif

