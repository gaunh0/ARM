#ifndef _APPLICATION_H
#define _APPLICATION_H

#include "stm8s_board.h"
#include "stdlib.h"


#endif

