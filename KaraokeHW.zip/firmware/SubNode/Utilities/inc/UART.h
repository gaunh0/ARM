#ifndef _UARTDEBUG_
#define _UARTDEBUG_

#include "stm8s_uart1.h"

void UART_InitController(uint32_t _baudrate);
void UART_SendByte(uint8_t c);
void UART_SendChar(char c);
void UART_SendString(uint8_t *data_buff);
void UART_SendStringLength(uint8_t* data_buff, uint8_t _length);
void UART_SendNumber(uint32_t value, uint8_t num_digit);  
void UART_Receive_ISR(void);
void UART_SendNumber(uint32_t value, uint8_t num_digit);
uint8_t UART_ReceiveByte(void);
uint8_t UART_DataAvailable(void);
void UART_ClearRxBuffer(void);
#endif

