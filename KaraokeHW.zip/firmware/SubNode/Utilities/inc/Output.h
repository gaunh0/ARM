#ifndef OUTPUT_H
#define OUTPUT_H

#include "stm8s.h"

#define RELAY1_PORT  		GPIOC
#define RELAY1_PIN  		GPIO_PIN_3

#define RELAY2_PORT  		GPIOC
#define RELAY2_PIN   		GPIO_PIN_4

#define LED_PORT			GPIOD
#define LED_PIN   			GPIO_PIN_1

#ifndef ON
#define ON  1
#endif

#ifndef OFF
#define OFF 0
#endif

void OutputInitController();
void Relay1High();
void Relay1Low();
void Relay2High();
void Relay2Low();
void LedOn();
void LedOff();
void LedToggle();

#endif

