 #ifndef _SOFTPWM_H
 #define _SOFTPWM_H

#include "stm8s_board.h"

#define MAX_PWM		100
#define DIMMER_ON	1
#define DIMMER_OFF 	0

void SoftPWMInitController();
void SoftPWMService();
void LEDDimmer(uint8_t led,uint8_t _value);

#endif
 
