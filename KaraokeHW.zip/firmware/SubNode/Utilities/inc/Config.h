#ifndef CONFIG_H
#define CONFIG_H


#define ADC_CHANNEL 2
#define AIR_CHANNEL		0
#define SOUND_CHANNEL	1 

#endif
