 /**
  ******************************************************************************
  * @file    Project/main.c 
  * @author  MCD Application Team
  * @version V2.1.0
  * @date    18-November-2011
  * @brief   Main program body
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************
  */ 


/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "KaraokeSubNode.h"

volatile uint16_t cnt =0;
void SysTick_AppsCaller(void){
	VTimerService();		
    	InputService();
	ReadADCValue();
	if (cnt>1000){			// 1 second
		CheckDeviceStatusService();		
		//UART_SendNumber(GetADCValueMax(AIR_CHANNEL),5);
		//UART_SendString("\r\n\t");
		//UART_SendNumber(GetADCValueMax(SOUND_CHANNEL),5);
		//UART_SendString("\r\n\t");
		ClearADCValueMax();
		/*if (GetAirConditionStatus() == ON){
			UART_SendString("AIR ON\r\n\t");
		}
		else {
			UART_SendString("AIR OFF\r\n\t");
		}
		if (GetSoundSystemStatus() == ON){
			UART_SendString("SOUND ON\r\n\t");
		}
		else {
			UART_SendString("SOUND OFF\r\n\t");
		}*/
		//LedToggle();
		cnt = 0;
	}
	else {
		cnt++;
	}
}

void main(void)
{	
	BoardInit();	
	SystemInit();	

	while (1)      
	{	
		IWDG_ReloadCounter();
      		SystemRunning();      	
	}
}

void assert_failed(u8* file, u32 line)
{ 
	/* User can add his own implementation to report the file name and line number,
	 ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

	/* Infinite loop */
	while (1)
	{
	}
}


/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
