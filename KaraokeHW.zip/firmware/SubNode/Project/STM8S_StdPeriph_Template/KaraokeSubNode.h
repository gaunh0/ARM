#ifndef _KARAOKESUBNODE_H
#define _KARAOKESUBNODE_H

#include "RS485.h"
#include "UART.h"
#include "Timer.h"
#include "VTimer.h"
#include "Input.h"
#include "Output.h"
#include "ADC.h"
#include "Config.h"

#define DATA_LENGTH_DEFAULT 2

#define HEADER_DLE		0x10
#define HEADER_STX		0x02

#define FOOTER_DLE		0x10
#define FOOTER_ETX		0x03

#define ADD0_CHITHUY		0x80
#define ADD1_TIENGIANG1	0x01
#define ADD2_BROADCAST	0x00

#define CMD_TURNON		0x81
#define CMD_TURNOFF		0x82
#define CMD_GETSTATUS	0x83
#define CMD_RESPONSE		0x84

#define AIRCONDITION_MASK	0x01
#define SOUNDSYSTEM_MASK	0x02	  

#define RS485_HEADER_DLE_STATE 		0
#define RS485_HEADER_STX_STATE 		1
#define RS485_ADDRESS0_STATE		2
#define RS485_ADDRESS1_STATE		3
#define RS485_ADDRESS2_STATE		4
#define RS485_COMMAND_STATE		5
#define RS485_DATALENGTH_STATE		6
#define RS485_DATA0_STATE			7
#define RS485_DATA1_STATE			8
#define RS485_GETCRC_HIGH_STATE		9
#define RS485_GETCRC_LOW_STATE		10
#define RS485_CHECKCRC_STATE		11	
#define RS485_FOOTER_DLE_STATE 		12
#define RS485_FOOTER_ETX_STATE 		13

#define COMMAND_STATUS_SUCCESS			1
#define COMMAND_STATUS_CRCFAIL			2
#define COMMAND_STATUS_ERROR			0xF0

#define ADDRESS_AIRCONDITION_STATUS		0x9FFD
#define ADDRESS_SOUNDSYSTEM_STATUS		0x9FFF
typedef struct {
	uint8_t Address[3];	
	uint8_t Command;
	uint8_t DataLength;
	uint8_t Data[2];
}Command_Typedef;

void BoardInit();
void DeviceInitController();
void SystemInit();
void SystemRunning();
void Watchdog_Config();
void SystemTest();

void TurnOnAirCondition();
void TurnOffAirCondition();
void TurnOnSoundSystem();
void TurnOffSoundSystem();
uint16_t CRC16Update(uint16_t crc, uint8_t data);
uint16_t CalculateCRC16(uint8_t *data, uint8_t len);
void SubNodeResponseCommand(uint8_t _ErrorCode);
void RS485ResetDataReceive();
uint8_t RS485GetResponseData();
void CheckDeviceStatusService();
uint8_t GetAirConditionStatus();
uint8_t GetSoundSystemStatus();

#endif

