#include "KaraokeSubNode.h"

#define CRC16_IBM		0x8005		// ModBus, USB, Bisync, CRC-16, CRC-16-ANSI, ...
#define POLYNOM		CRC16_IBM

Command_Typedef CommandReceive;
uint8_t VTimerRS485ReceiveTimeout;
uint8_t VTimetCheckSubAlive = 0;
uint8_t NodeSetAddress = 0;

#define RS485_CRC_BUFFER_SIZE 	12
uint8_t rs485_buffer_calculateCRC[RS485_CRC_BUFFER_SIZE];
uint8_t rs485_buffer_calculateCRC_index = 0;
uint16_t rs485_crcvalue_temp = 0;
uint8_t rs485_crc_length = 0;

volatile uint8_t rs485_receive_state = 0;
volatile uint8_t rs485_receive_substate = 0;
volatile uint8_t rs485_data_length = 0;
volatile uint16_t rs485_crc_receive = 0;
volatile uint8_t rs485_receive_success_flag = 0;
volatile uint8_t rs485_receive_success_code = 0;
volatile uint8_t AirConditionStatus;
volatile uint8_t AirConditionRealStatus;
volatile uint8_t SoundSystemStatus;
volatile uint8_t SoundSystemRealStatus;

void BoardInit(){
	CLK_DeInit();
	CLK_HSIPrescalerConfig(CLK_PRESCALER_HSIDIV1);
	CLK_LSICmd(ENABLE);	
	
	TimerInitController();			
	ADCInitController();
	enableInterrupts();
	RS485InitController();	
	OutputInitController();
	InputInitController();
	DeviceInitController(); 	
	/**** Flash init ****/
	/*Define FLASH programming time*/
	FLASH_SetProgrammingTime(FLASH_PROGRAMTIME_STANDARD);
	/* Unlock Data FLASH memory */
	FLASH_Unlock(FLASH_MEMTYPE_PROG);
	
	// Check if the MCU has resumed from IWDG reset 	
	Watchdog_Config();
}


void DeviceInitController(){
	//TurnOffAirCondition();
	//TurnOffSoundSystem();
       AirConditionStatus = FLASH_ReadByte(ADDRESS_AIRCONDITION_STATUS);
	SoundSystemStatus= FLASH_ReadByte(ADDRESS_SOUNDSYSTEM_STATUS);
	if ( AirConditionStatus == ON){
		TurnOnAirCondition();
	}
	else {
		TurnOffAirCondition();
	}
	if ( SoundSystemStatus == ON){
		TurnOnSoundSystem();
	}
	else {
		TurnOffSoundSystem();
	}
	LedOff();
	CommandReceive.Address[0] = 0;
	CommandReceive.Address[1] = 0;
	CommandReceive.Address[2] = 0;
	CommandReceive.Command = 0;
	CommandReceive.DataLength = DATA_LENGTH_DEFAULT;
	CommandReceive.Data[0] = 0;
	CommandReceive.Data[1] = 0;
	VTimerRS485ReceiveTimeout = VTimerGetID();
	VTimetCheckSubAlive = VTimerGetID();
	VTimerSet(VTimetCheckSubAlive, 30000);
}

void TurnOnAirCondition(){
	Relay1Low();
	AirConditionStatus = ON;
	FLASH_ProgramByte(ADDRESS_AIRCONDITION_STATUS,AirConditionStatus);
}
void TurnOffAirCondition(){
	Relay1High();
	AirConditionStatus = OFF;
	FLASH_ProgramByte(ADDRESS_AIRCONDITION_STATUS,AirConditionStatus);
}
void TurnOnSoundSystem(){
	Relay2Low();
	SoundSystemStatus = ON;
	FLASH_ProgramByte(ADDRESS_SOUNDSYSTEM_STATUS,SoundSystemStatus);
}
void TurnOffSoundSystem(){
	Relay2High();
	SoundSystemStatus = OFF;
	FLASH_ProgramByte(ADDRESS_SOUNDSYSTEM_STATUS,SoundSystemStatus);
}

void SubNodeResponseCommand(uint8_t _ErrorCode){
	rs485_buffer_calculateCRC[0] = CommandReceive.Address[0];
	rs485_buffer_calculateCRC[1] = CommandReceive.Address[1];
	rs485_buffer_calculateCRC[2] = CommandReceive.Address[2];
	rs485_buffer_calculateCRC[3] = CommandReceive.Command;
	rs485_buffer_calculateCRC[4] = DATA_LENGTH_DEFAULT;
	rs485_buffer_calculateCRC[5] = _ErrorCode;
	rs485_buffer_calculateCRC[6] = 0x00;
	rs485_crcvalue_temp = CalculateCRC16(rs485_buffer_calculateCRC,7);
	RS485Transmit();
	RS485SendByte(HEADER_DLE);
	RS485SendByte(HEADER_STX);
	RS485SendByte(CommandReceive.Address[0]);
	RS485SendByte(CommandReceive.Address[1]);
	RS485SendByte(CommandReceive.Address[2]);
	RS485SendByte(CommandReceive.Command);
	RS485SendByte(DATA_LENGTH_DEFAULT);
	RS485SendByte(_ErrorCode);
	RS485SendByte(0x00);
	RS485SendByte(rs485_crcvalue_temp>>8);
	RS485SendByte(rs485_crcvalue_temp);					
	RS485SendByte(FOOTER_DLE);
	RS485SendByte(FOOTER_ETX);
	RS485ResetDataReceive();
	RS485Receive();
}
void SubNodeResponseStatus(uint8_t _ErrorCode){
	uint8_t _temp = 0;
	if ( GetAirConditionStatus()== ON){
		_temp |= AIRCONDITION_MASK;
	}
	else {
		_temp &= ~AIRCONDITION_MASK;
	}
	if ( GetSoundSystemStatus()== ON){
		_temp |= SOUNDSYSTEM_MASK;
	}
	else {
		_temp &= ~SOUNDSYSTEM_MASK;
	}
	rs485_buffer_calculateCRC[0] = CommandReceive.Address[0];
	rs485_buffer_calculateCRC[1] = CommandReceive.Address[1];
	rs485_buffer_calculateCRC[2] = CommandReceive.Address[2];
	rs485_buffer_calculateCRC[3] = CommandReceive.Command;
	rs485_buffer_calculateCRC[4] = DATA_LENGTH_DEFAULT;
	rs485_buffer_calculateCRC[5] = _ErrorCode;
	rs485_buffer_calculateCRC[6] = _temp;
	rs485_crcvalue_temp = CalculateCRC16(rs485_buffer_calculateCRC,7);
	RS485Transmit();
	RS485SendByte(HEADER_DLE);
	RS485SendByte(HEADER_STX);
	RS485SendByte(CommandReceive.Address[0]);
	RS485SendByte(CommandReceive.Address[1]);
	RS485SendByte(CommandReceive.Address[2]);
	RS485SendByte(CommandReceive.Command);
	RS485SendByte(DATA_LENGTH_DEFAULT);
	RS485SendByte(_ErrorCode);
	RS485SendByte(_temp);
	RS485SendByte(rs485_crcvalue_temp>>8);
	RS485SendByte(rs485_crcvalue_temp);					
	RS485SendByte(FOOTER_DLE);
	RS485SendByte(FOOTER_ETX);
	RS485ResetDataReceive();
	RS485Receive();
}
void SystemInit(){
	RS485Receive();
	do {
		NodeSetAddress = GetDipSWValue();
		DelayMs(100);
	}while (NodeSetAddress != GetDipSWValue());
	RS485ResetDataReceive();
	if (RST_GetFlagStatus(RST_FLAG_IWDGF) != RESET){
		RST_ClearFlag(RST_FLAG_IWDGF);	
		RS485Transmit();
		RS485SendString("SUB_RESET_\t");
		RS485SendNumber(GetDipSWValue(),3);
		RS485Receive();		
	}
          RS485Transmit();
          RS485SendString("sub_reset_\t");
          RS485SendNumber(GetDipSWValue(),3);
          RS485Receive();
}
uint8_t systemCode=0;
void SystemRunning(){	
	RS485GetResponseData();	
}
void Watchdog_Config(){
	IWDG_Enable();
	IWDG_WriteAccessCmd(IWDG_WriteAccess_Enable);
	IWDG_SetPrescaler(IWDG_Prescaler_256);
	IWDG_SetReload(0xFF);
}

uint16_t CRC16Update(uint16_t crc, uint8_t data){
	uint8_t i;
	for (i = 0; i < 8; i++) {
		if (((crc & 0x8000) >> 8 ) ^ (data & 0x80)){
			crc = (crc << 1) ^ POLYNOM;
		}
		else{
			crc = (crc << 1);
		}
		data <<= 1;
	}
	return crc;
}
uint16_t CalculateCRC16(uint8_t *data, uint8_t len){
	uint16_t crc;
	uint8_t i = 0; 
	// CRC Initialization
	crc = 0x0000;
	while (i < len){
		crc = CRC16Update(crc, data[i]);
		i++;
	}
	return crc;
}


void RS485ResetDataReceive(){
	uint8_t _i=0;
	rs485_receive_state = RS485_HEADER_DLE_STATE;
	rs485_receive_success_flag = COMMAND_STATUS_ERROR;
	rs485_receive_success_code = COMMAND_STATUS_ERROR;	
	rs485_buffer_calculateCRC_index = 0;
	for (_i=0;_i<RS485_CRC_BUFFER_SIZE;_i++){
		rs485_buffer_calculateCRC[_i] = 0;
	}
	UART_ClearRxBuffer();
}
volatile uint8_t ReceiveByte = 0;	
uint8_t RS485GetResponseData(){		
	if (VTimerIsFired(VTimerRS485ReceiveTimeout)){
		VTimerSet(VTimerRS485ReceiveTimeout,300);
		RS485ResetDataReceive();
	}
	if (VTimerIsFired(VTimetCheckSubAlive)){
		TurnOnAirCondition();
		TurnOnSoundSystem();
	}
	if (UART_DataAvailable()){
		ReceiveByte = UART_ReceiveByte();
		VTimerSet(VTimerRS485ReceiveTimeout,300);
		VTimerSet(VTimetCheckSubAlive,10000);
		switch (rs485_receive_state){
			case RS485_HEADER_DLE_STATE:
				if (ReceiveByte == HEADER_DLE){		
					rs485_receive_state = RS485_HEADER_STX_STATE;
				}
				else {
					rs485_receive_success_flag = COMMAND_STATUS_ERROR;	
					RS485ResetDataReceive();
				}
				break;
			case RS485_HEADER_STX_STATE:
				if (ReceiveByte == HEADER_STX){
					rs485_receive_state = RS485_ADDRESS0_STATE;
				}
				else {
					rs485_receive_success_flag = COMMAND_STATUS_ERROR;	
					RS485ResetDataReceive();
				}
				break;
			case RS485_ADDRESS0_STATE:		
				if (ReceiveByte == ADD0_CHITHUY){
					CommandReceive.Address[0]  = ReceiveByte;
					rs485_buffer_calculateCRC[rs485_buffer_calculateCRC_index] = ReceiveByte;
					rs485_buffer_calculateCRC_index++;
					rs485_receive_state = RS485_ADDRESS1_STATE ;
				}
				else {
					rs485_receive_success_flag = COMMAND_STATUS_ERROR;	
					RS485ResetDataReceive();
				}
				break;
			case RS485_ADDRESS1_STATE:				
				if (ReceiveByte == ADD1_TIENGIANG1){
					CommandReceive.Address[1]  = ReceiveByte;
					//UART_SendString("Test2\r\n\t");
					rs485_buffer_calculateCRC[rs485_buffer_calculateCRC_index] = ReceiveByte;
					rs485_buffer_calculateCRC_index++;
					rs485_receive_state = RS485_ADDRESS2_STATE ;
				}
				else {
					rs485_receive_success_flag = COMMAND_STATUS_ERROR;	
					RS485ResetDataReceive();
				}
				break;
			case RS485_ADDRESS2_STATE:				
				if ((ReceiveByte == 0) || (ReceiveByte == NodeSetAddress)){
					CommandReceive.Address[2]  = ReceiveByte;					
					rs485_buffer_calculateCRC[rs485_buffer_calculateCRC_index] = ReceiveByte;
					rs485_buffer_calculateCRC_index++;
					rs485_receive_state = RS485_COMMAND_STATE ;
				}
				else {
					rs485_receive_success_flag = COMMAND_STATUS_ERROR;	
					RS485ResetDataReceive();
				}
				break;	
			case RS485_COMMAND_STATE:					
					CommandReceive.Command = ReceiveByte;	
					//UART_SendString("Test4\r\n\t");
					rs485_buffer_calculateCRC[rs485_buffer_calculateCRC_index] = ReceiveByte;
					rs485_buffer_calculateCRC_index++;
					rs485_receive_state = RS485_DATALENGTH_STATE ;
				break;
			case RS485_DATALENGTH_STATE:
					CommandReceive.DataLength = ReceiveByte;		
					//UART_SendString("Test5\r\n\t");
					rs485_buffer_calculateCRC[rs485_buffer_calculateCRC_index] = ReceiveByte;
					rs485_buffer_calculateCRC_index++;	
					rs485_receive_state = RS485_DATA0_STATE ;
				break;
			case RS485_DATA0_STATE:
					CommandReceive.Data[0] = ReceiveByte;
					//UART_SendString("Tes6\r\n\t");
					rs485_buffer_calculateCRC[rs485_buffer_calculateCRC_index] = ReceiveByte;
					rs485_buffer_calculateCRC_index++;
					rs485_receive_state = RS485_DATA1_STATE ;
				break;
			case RS485_DATA1_STATE:
					CommandReceive.Data[1] = ReceiveByte;
					//UART_SendString("Tes6\r\n\t");
					rs485_buffer_calculateCRC[rs485_buffer_calculateCRC_index] = ReceiveByte;
					rs485_buffer_calculateCRC_index++;
					rs485_receive_state = RS485_GETCRC_HIGH_STATE ;
				break;	
			case RS485_GETCRC_HIGH_STATE:
					//UART_SendString("Test7\r\n\t");
					rs485_crc_receive =ReceiveByte;					
					rs485_crc_receive = rs485_crc_receive << 8;
					rs485_receive_state = RS485_GETCRC_LOW_STATE;
				break;	
			case RS485_GETCRC_LOW_STATE:	
					//UART_SendString("Test8\r\n\t");
					rs485_crc_receive |= ReceiveByte;	
					if (rs485_crc_receive == CalculateCRC16(rs485_buffer_calculateCRC,rs485_buffer_calculateCRC_index) ){	
						rs485_receive_success_code = COMMAND_STATUS_SUCCESS;	
					}
					else {
						rs485_receive_success_code = COMMAND_STATUS_CRCFAIL;	
					}
					rs485_receive_state = RS485_FOOTER_DLE_STATE;					
					break;
			case RS485_FOOTER_DLE_STATE:
				//UART_SendString("Test9\r\n\t");
				if (ReceiveByte == HEADER_DLE){
					rs485_receive_state = RS485_FOOTER_ETX_STATE;	
				}
				else {
					rs485_receive_success_flag = COMMAND_STATUS_ERROR;	
					RS485ResetDataReceive();
				}
				break;
			case RS485_FOOTER_ETX_STATE:	
				//UART_SendString("Test10\r\n\t");
				if (ReceiveByte == FOOTER_ETX){
					rs485_receive_success_flag = COMMAND_STATUS_SUCCESS;
				}
				else {
					rs485_receive_success_flag = COMMAND_STATUS_ERROR;	
					RS485ResetDataReceive();
				}
				break;
			default:
				RS485ResetDataReceive();
				break;
		}
	}
	if (rs485_receive_success_flag == COMMAND_STATUS_SUCCESS){		
		switch (CommandReceive.Command){
			case CMD_TURNON:
				if ((CommandReceive.Data[1] & AIRCONDITION_MASK) == AIRCONDITION_MASK){
					TurnOnAirCondition();
					LedOn();
				}
				if ((CommandReceive.Data[1] & SOUNDSYSTEM_MASK) == SOUNDSYSTEM_MASK){
					TurnOnSoundSystem();
					LedOn();
				}
				if (CommandReceive.Address[2] != 0){
					SubNodeResponseCommand(rs485_receive_success_code);
				}
				break;
			case CMD_TURNOFF:
				if ((CommandReceive.Data[1] & AIRCONDITION_MASK) == AIRCONDITION_MASK){
					TurnOffAirCondition();
					LedOff();
				}
				if ((CommandReceive.Data[1] & SOUNDSYSTEM_MASK)== SOUNDSYSTEM_MASK){
					TurnOffSoundSystem();
					LedOff();
				}
				if (CommandReceive.Address[2] != 0){
					SubNodeResponseCommand(rs485_receive_success_code);
				}
				break;
			case CMD_GETSTATUS:
				if (CommandReceive.Address[2] != 0){
					SubNodeResponseStatus(rs485_receive_success_code);
				}
				break;
			default:
				break;
		}
		
		rs485_receive_success_flag = COMMAND_STATUS_ERROR;	
		rs485_receive_state = RS485_HEADER_DLE_STATE;
	}
	return rs485_receive_success_flag;
}

void CheckDeviceStatusService(){
	if (GetADCValueMax(AIR_CHANNEL) > 50){
		AirConditionRealStatus = ON;
	}
	else {
		AirConditionRealStatus = OFF;
	}
	if (GetADCValueMax(SOUND_CHANNEL) > 50){
		SoundSystemRealStatus = ON;
	}
	else {
		SoundSystemRealStatus = OFF;
	}
}
uint8_t GetAirConditionStatus(){
	return AirConditionRealStatus;
}

uint8_t GetSoundSystemStatus(){
	return SoundSystemRealStatus;
}

 
