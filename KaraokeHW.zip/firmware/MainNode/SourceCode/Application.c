#include "Application.h"
#include "crypto.h"
#include "Flash.h"

uint8_t GetCommandFromPCFlag = 0;
uint8_t CommandBuffer[COMMAND_LENGTH];
uint8_t GetDataFromPCComplete = 0;
uint8_t BufferIndex = 0;
uint8_t CommandIndex = 0;
uint8_t PCReceiveByte = 0;
uint8_t PCReceiveState = 0;

uint8_t SystemMode = 0;
uint8_t MaxSubNode = 0;
uint8_t SubNodeIndex = 1;

uint8_t VTimerPCReceiveTimeout = 0;
uint8_t VTimerManualMode = 0;
uint8_t VTimerButtonPress_ID = 0;
uint8_t VTimerButtonDelay_ID = 0;

uint8_t BufferCalculateCRC[40];
uint16_t MainKey = 0;
uint8_t AuthenticateFlag = 0;
uint8_t CommandAutoModeReceive = 0;

uint8_t ButtonProcessState = 0;

uint8_t DeviceState[255];
void ApplicationInit(void){
	uint16_t i;
	GetCommandFromPCFlag = 0;
	BufferIndex = 0;
	CommandIndex = 0;
	VTimerPCReceiveTimeout = VTimerGetID();
	VTimerManualMode = VTimerGetID();
	VTimerButtonPress_ID = VTimerGetID();
	VTimerButtonDelay_ID = VTimerGetID();
	
	AuthenticateFlag = 0;
	LedOff();
	for (i=0;i<255;i++){
		DeviceState[i] = 0;
	}
	MaxSubNode = LoadNumberRoomConfig();
	if (MaxSubNode == 255) {
		MaxSubNode = 0;
	}
	LCDPrintStringCenter(0,"Karaoke Cosy");
	if (GetSwitchModeValue() == LOW_STATE){		
		SystemMode = MAIN_BACKUP_MODE;
	}
	else {
		LCDPrintStringCenter(1,"                ");
		LCDPrintStringCenter(1,"System Running");
		SystemMode = MAIN_ENCRYPTION;	
	}
}

void ApplicationRunning(void){	
	switch (SystemMode){		
		case MAIN_BACKUP_MODE:
			LedOff();
			SystemBackupMode();
			break;
		case MAIN_PC_MODE:
			LedOn();
			SystemPCMode();
			break;
		case MAIN_STANDBY_MODE:
			SystemStandbyMode();
			break;
		case MAIN_ENCRYPTION:
			PCAuthenticate();
			break;	
		default:
			break;			
	}
}

void ResetPCDataReceive(){
	uint8_t _index = 0;
	PCReceiveState = HEADER_DLE_STATE;	
	for (_index = 0; _index<COMMAND_LENGTH;_index++){
		CommandBuffer[_index] = 0;
	}
	GetDataFromPCComplete = 0;
}

void SystemPCMode(){
	if (GetSwitchModeValue() == LOW_STATE){
		LCDPrintStringCenter(1,"                ");
		LCDPrintString(0,1,"MANUAL MODE");
		LCDPrintNumber(13,1,MaxSubNode,3);
		SystemMode = MAIN_BACKUP_MODE;
	}
	if (UARTPCRXAvailable()){
		PCReceiveByte = UARTPCReceivedByte();
		VTimerSet(VTimerPCReceiveTimeout,500);
		switch (PCReceiveState){
			case HEADER_DLE_STATE:
				CommandIndex = 0;
				if (PCReceiveByte == HEADER_DLE){		
					CommandBuffer[CommandIndex] = PCReceiveByte;
					CommandIndex ++;
					PCReceiveState = HEADER_STX_STATE;
				}
				else {
					ResetPCDataReceive();
				}
				break;
			case HEADER_STX_STATE:
				if (PCReceiveByte == HEADER_STX){
					CommandBuffer[CommandIndex] = PCReceiveByte;
					CommandIndex++;
					PCReceiveState = ADDRESS0_STATE;
				}
				else {
					ResetPCDataReceive();
				}
				break;
			case ADDRESS0_STATE:	
				
				if (PCReceiveByte == ADD0){
					CommandBuffer[CommandIndex] = PCReceiveByte;
					CommandIndex++;
					PCReceiveState = ADDRESS1_STATE ;
				}
				break;
			case ADDRESS1_STATE:				
				if (PCReceiveByte == ADD1){
					CommandBuffer[CommandIndex] = PCReceiveByte;
					CommandIndex++;
					PCReceiveState = ADDRESS2_STATE ;
				}
				break;
			case ADDRESS2_STATE:				
					CommandBuffer[CommandIndex] = PCReceiveByte;
					CommandIndex++;
					PCReceiveState = COMMAND_STATE ;
				break;	
			case COMMAND_STATE:		
					CommandAutoModeReceive = PCReceiveByte;
					CommandBuffer[CommandIndex] = PCReceiveByte;
					CommandIndex++;
					PCReceiveState = DATALENGTH_STATE ;
				break;
			case DATALENGTH_STATE:
					CommandBuffer[CommandIndex] = PCReceiveByte;
					CommandIndex++;	
					PCReceiveState = DATA0_STATE ;
				break;
			case DATA0_STATE:
					CommandBuffer[CommandIndex] = PCReceiveByte;
					CommandIndex++;
					PCReceiveState = DATA1_STATE ;
				break;
			case DATA1_STATE:
					CommandBuffer[CommandIndex] = PCReceiveByte;
					CommandIndex++;
					PCReceiveState = GETCRC_HIGH_STATE ;
				break;	
			case GETCRC_HIGH_STATE:
					CommandBuffer[CommandIndex] = PCReceiveByte;
					CommandIndex++;
					PCReceiveState = GETCRC_LOW_STATE;
				break;	
			case GETCRC_LOW_STATE:	
					CommandBuffer[CommandIndex] = PCReceiveByte;
					CommandIndex++;
					PCReceiveState = FOOTER_DLE_STATE;					
					break;
			case FOOTER_DLE_STATE:
				if (PCReceiveByte == FOOTER_DLE){
					CommandBuffer[CommandIndex] = PCReceiveByte;
					CommandIndex++;
					PCReceiveState = FOOTER_ETX_STATE;	
				}
				else {
					ResetPCDataReceive();
				}
				break;
			case FOOTER_ETX_STATE:
				if (PCReceiveByte == FOOTER_ETX){					
					CommandBuffer[CommandIndex] = PCReceiveByte;
					CommandIndex = 0;
					GetDataFromPCComplete = 1;
					PCReceiveState = HEADER_DLE_STATE;	
				}
				else {
					ResetPCDataReceive();
				}
				break;
			default:
				ResetPCDataReceive();
				break;
		}
		if (GetDataFromPCComplete == 1){
			if (AuthenticateFlag == 0){
				MainResponseNotAuthenticate(CommandBuffer[COMMAND_INDEX]);
			}
			else {
				if (CommandBuffer[COMMAND_INDEX] == CMD_CONFIG){
					if (CommandBuffer[DATA0_INDEX]  == 0x01){
						BuzzerSound(100,100,1);
						MaxSubNode = CommandBuffer[DATA1_INDEX];
						SaveNumberRoomConfig(MaxSubNode);
						MainResponse(CommandBuffer[COMMAND_INDEX]);
						LCDPrintStringCenter(1,"                ");
						LCDPrintString(0,1,"Total Room = ");
						LCDPrintNumber(13,1,MaxSubNode,3);
						DelayMs(1000);
						LCDPrintStringCenter(1,"                ");
						LCDPrintStringCenter(1,"System Running");
					}
					else {
						MainResponseError(CommandBuffer[COMMAND_INDEX]);
					}
				}
				else {
					RS485Transmit();
					RS485SendStringLength(CommandBuffer, COMMAND_LENGTH);
					RS485Receive();
				}
			}
			GetDataFromPCComplete = 0;
		}
	}
	GetDataFromRS485();
}

void SystemBackupMode(){
	uint8_t BackupModeState = 0;
	uint8_t room_index;
	uint16_t CRCValue;	
	SubNodeIndex = 1;
	LCDClear();
	LCDPrintStringCenter(1,"                ");
	LCDPrintString(0,1,"MANUAL MODE");
	LCDPrintNumber(13,1,MaxSubNode,3);
	DisplayControlRoomManualMode(SubNodeIndex,DeviceState[SubNodeIndex]);
	SendDataToSubNodeManualMode(SubNodeIndex,DeviceState[SubNodeIndex]);
	while (GetSwitchModeValue() == LOW_STATE){
		if (BackupModeState == MANUAL_MODE){
			switch (ButtonProcessState){
				case FIRST_PRESS:
					if (PressUP()){
						VTimerSet(VTimerButtonPress_ID,2000);
						ButtonProcessState = UP_TIMER_PRESS;
					}
					else if (PressDOWN()){
						VTimerSet(VTimerButtonPress_ID,2000);
						ButtonProcessState = DOWN_TIMER_PRESS;
					}
					else if (PressSELECT()){
						VTimerSet(VTimerButtonPress_ID,2000);
						ButtonProcessState = SELECT_TIMER_PRESS;
					}
					break;
				case UP_TIMER_PRESS:
					if (VTimerIsFired(VTimerButtonPress_ID)){					
						ButtonProcessState = UP_LONG_PRESS;
					}
					else {
						if (!PressUP()){
							ButtonProcessState = UP_SHORT_PRESS;
						}				
					}
					break;
				case DOWN_TIMER_PRESS:
					if (VTimerIsFired(VTimerButtonPress_ID)){
						ButtonProcessState = DOWN_LONG_PRESS;
					}
					else {
						if (!PressDOWN()){
							ButtonProcessState = DOWN_SHORT_PRESS;
						}				
					}
					break;
				case SELECT_TIMER_PRESS:
					if (VTimerIsFired(VTimerButtonPress_ID)){	
						BuzzerSound(100,100,2);
						ButtonProcessState = SELECT_LONG_PRESS;
					}
					else {
						if (!PressSELECT()){
							ButtonProcessState = SELECT_SHORT_PRESS;
						}				
					}				
					break;	
				case UP_SHORT_PRESS:			
					if (SubNodeIndex >= MaxSubNode){
						SubNodeIndex = 1;
					}	
					else SubNodeIndex++;
					DisplayControlRoomManualMode(SubNodeIndex,DeviceState[SubNodeIndex]);
					ButtonProcessState = FIRST_PRESS;			
					break;
				case UP_LONG_PRESS:
					if (VTimerIsFired(VTimerButtonDelay_ID)){
						SubNodeIndex+=10;
						if (SubNodeIndex > MaxSubNode){
							SubNodeIndex = 1;
						}
						DisplayControlRoomManualMode(SubNodeIndex,DeviceState[SubNodeIndex]);
						VTimerSet(VTimerButtonDelay_ID,500);
					}
					if (!PressUP()){
						ButtonProcessState = FIRST_PRESS;
					}	
					
					break;
				case DOWN_SHORT_PRESS:			
					if (SubNodeIndex <= 1){
						SubNodeIndex = MaxSubNode;
					}	
					else SubNodeIndex--;
					DisplayControlRoomManualMode(SubNodeIndex,DeviceState[SubNodeIndex]);
					ButtonProcessState = FIRST_PRESS;
					break;
				case DOWN_LONG_PRESS:	
					if (VTimerIsFired(VTimerButtonDelay_ID)){
						if (SubNodeIndex < 11){
							SubNodeIndex = MaxSubNode;
						}
						else {
							SubNodeIndex-=10;
						}
						DisplayControlRoomManualMode(SubNodeIndex,DeviceState[SubNodeIndex]);
						VTimerSet(VTimerButtonDelay_ID,500);
					}
					if (!PressDOWN()){
						ButtonProcessState = FIRST_PRESS;
					}
					
					break;	
				case SELECT_SHORT_PRESS:
					if (VTimerIsFired(VTimerButtonDelay_ID)){
						DeviceState[SubNodeIndex]++;
						DeviceState[SubNodeIndex] = DeviceState[SubNodeIndex]% 2;
						DisplayControlRoomManualMode(SubNodeIndex,DeviceState[SubNodeIndex]);
						SendDataToSubNodeManualMode(SubNodeIndex,DeviceState[SubNodeIndex]);
						VTimerSet(VTimerButtonDelay_ID,500);
					}
					ButtonProcessState = FIRST_PRESS;
					break;	
				case SELECT_LONG_PRESS:	
					if (!PressSELECT()){						
						BackupModeState = AUTO_MODE;
						LCDPrintStringCenter(1,"                ");
						LCDPrintString(0,1,"AUTO MODE");
						LCDPrintNumber(13,1,MaxSubNode,3);
						VTimerSet(VTimerButtonDelay_ID,2000);
						ButtonProcessState = FIRST_PRESS;
					}
					break;		
				default:
					break;
			}
		}
		else {
			room_index = 1;
			while (room_index <=MaxSubNode){
				if (VTimerIsFired(VTimerManualMode)){
					DeviceState[room_index] = DEVICE_ON;
					DisplayControlRoomManualMode(room_index,DeviceState[room_index]);
					SendDataToSubNodeManualMode(room_index,DeviceState[room_index]);
					VTimerSet(VTimerManualMode,2000);
					room_index++;
					
				}
				if (GetSwitchModeValue() == HIGH_STATE){
					if (AuthenticateFlag == 1){
						LCDClear();
						LCDPrintStringCenter(0,"Karaoke Cosy");
						LCDPrintStringCenter(1,"System Running");
						SystemMode = MAIN_PC_MODE;
						return;
					}
					else {
						LCDClear();
						LCDPrintStringCenter(0,"Karaoke Cosy");
						LCDPrintStringCenter(1,"Encryption");
						SystemMode = MAIN_ENCRYPTION;
						return;
					}
				}
				if (PressSELECT()){					
					while (PressSELECT());
					BuzzerSound(100,100,2);
					LCDPrintStringCenter(1,"                ");
					LCDPrintString(0,1,"MANUAL MODE");
					LCDPrintNumber(13,1,MaxSubNode,3);
					BackupModeState = MANUAL_MODE;
					DisplayControlRoomManualMode(1,DeviceState[1]);
					break;
				}
			}
		}
	}
	if (AuthenticateFlag == 1){
		LCDClear();
		LCDPrintStringCenter(0,"Karaoke Cosy");
		LCDPrintStringCenter(1,"System Running");
		SystemMode = MAIN_PC_MODE;
		return;
	}
	else {
		LCDClear();
		LCDPrintStringCenter(0,"Karaoke Cosy");
		LCDPrintStringCenter(1,"Encryption");
		SystemMode = MAIN_ENCRYPTION;
		return;
	}
	
	/*uint8_t room_index;
	uint16_t CRCValue;	
	uint8_t temp = 0x81;
	room_index = 1;
	LCDPrintStringCenter(0,"                ");
	while (room_index <=MaxSubNode){
		if (VTimerIsFired(VTimerManualMode)){
			LCDPrintString(0,0,"Room ");
			LCDPutDigi3(5,0,room_index);
			BufferCalculateCRC[0] = ADD0;
			BufferCalculateCRC[1] = ADD1;
			BufferCalculateCRC[2] = room_index;
			BufferCalculateCRC[3] = 0x81;
			BufferCalculateCRC[4] = DATA_LENGTH_DEFAULT;
			BufferCalculateCRC[5] = 0x00;
			BufferCalculateCRC[6] = 0x03;
			CRCValue = CalculateCRC16(BufferCalculateCRC,7);	
			RS485Transmit();
			RS485SendByte(HEADER_DLE);
			RS485SendByte(HEADER_STX);
			RS485SendByte(ADD0);
			RS485SendByte(ADD1);
			RS485SendByte(room_index);
			RS485SendByte(0x81);
			RS485SendByte(DATA_LENGTH_DEFAULT);
			RS485SendByte(0x00);
			RS485SendByte(0x03);
			RS485SendByte(CRCValue>>8);
			RS485SendByte(CRCValue);					
			RS485SendByte(FOOTER_DLE);
			RS485SendByte(FOOTER_ETX);
			RS485Receive();
			VTimerSet(VTimerManualMode,2000);
			room_index++;
			
		}
		if (GetSwitchModeValue() == HIGH_STATE){
			if (AuthenticateFlag == 1){
				LCDClear();
				LCDPrintStringCenter(0,"Karaoke Cosy");
				LCDPrintStringCenter(1,"System Running");
				SystemMode = MAIN_PC_MODE;
				return;
			}
			else {
				LCDClear();
				LCDPrintStringCenter(0,"Karaoke Cosy");
				LCDPrintStringCenter(1,"Encryption");
				SystemMode = MAIN_ENCRYPTION;
				return;
			}
		}
	}*/	
}
void SystemStandbyMode(){
	if (GetSwitchModeValue() == HIGH_STATE){
		SystemMode = MAIN_PC_MODE;
	}
}

void PCAuthenticate(){
	uint8_t _index = 0;
	uint8_t TempBuffer[20];
	uint8_t DataLength = 0;
	
	uint8_t DataReceiveState = 0;
	uint8_t DataReceiveSubState = 0;
	uint8_t CommandRec = 0;

	uint8_t PCKey[4];
	uint8_t PCHash[16];
	uint8_t MainHash[16];
	
	uint8_t CRCBufferTemp[40];
	uint8_t CRCIndex = 0;
	uint16_t CRCReceive = 0;
	uint8_t CRCFlag = 0;
	LCDPrintStringCenter(1,"                ");
	LCDPrintStringCenter(1,"Encryption");
	while (AuthenticateFlag == 0){
		if (GetSwitchModeValue() == LOW_STATE){
			LCDPrintString(0,1,"MANUAL MODE");
			LCDPrintNumber(13,1,MaxSubNode,3);
			SystemMode = MAIN_BACKUP_MODE;
			break;
		}
		if (UARTPCRXAvailable()){
			PCReceiveByte = UARTPCReceivedByte();
			VTimerSet(VTimerPCReceiveTimeout,2000);
			switch (DataReceiveState){
				case HEADER_DLE_STATE:
					if (PCReceiveByte == HEADER_DLE){	
						DataReceiveState = HEADER_STX_STATE;
					}
					else {
						DataReceiveState = HEADER_DLE_STATE;
					}
					break;
				case HEADER_STX_STATE:
					if (PCReceiveByte == HEADER_STX){
						CRCIndex = 0;
						DataReceiveState = ADDRESS0_STATE;
					}
					else {
						DataReceiveState = HEADER_DLE_STATE;
					}
					break;
				case ADDRESS0_STATE:		
					if (PCReceiveByte == ADD0){		
						CRCBufferTemp[CRCIndex++] = PCReceiveByte;
						DataReceiveState = ADDRESS1_STATE ;
					}
					else {
						DataReceiveState = HEADER_DLE_STATE;
					}
					break;
				case ADDRESS1_STATE:				
					if (PCReceiveByte == ADD1){
						CRCBufferTemp[CRCIndex++] = PCReceiveByte;
						DataReceiveState = ADDRESS2_STATE ;
					}
					else {
						DataReceiveState = HEADER_DLE_STATE;
					}
					break;
				case ADDRESS2_STATE:		
						CRCBufferTemp[CRCIndex++] = PCReceiveByte;
						CommandRec = 0;
						DataReceiveState = COMMAND_STATE ;
					break;	
				case COMMAND_STATE:	
						CRCBufferTemp[CRCIndex++] = PCReceiveByte;
						CommandRec = PCReceiveByte;
						DataLength = 0;
						DataReceiveState = DATALENGTH_STATE ;
					break;
				case DATALENGTH_STATE:
						CRCBufferTemp[CRCIndex++] = PCReceiveByte;
						DataLength = PCReceiveByte;
						DataReceiveState = DATA0_STATE ;
						DataReceiveSubState = 0;
					break;
				case DATA0_STATE:
						CRCBufferTemp[CRCIndex++] = PCReceiveByte;						
						TempBuffer[DataReceiveSubState] = PCReceiveByte;
						DataReceiveSubState++;
						if (DataReceiveSubState >=DataLength){
							DataReceiveState = GETCRC_HIGH_STATE ;
							DataReceiveSubState = 0;
						}
					break;
				case GETCRC_HIGH_STATE:	
						CRCReceive = PCReceiveByte;						
						CRCReceive = CRCReceive << 8;
						CRCFlag = 0;
						DataReceiveState = GETCRC_LOW_STATE;
					break;	
				case GETCRC_LOW_STATE:	
						CRCReceive |= PCReceiveByte;
						if (CRCReceive == CalculateCRC16(CRCBufferTemp,CRCIndex)){							
							CRCFlag = COMMAND_STATUS_SUCCESS;	
						}
						else {
							CRCFlag = COMMAND_STATUS_CRCFAIL;								
						}
						DataReceiveState = FOOTER_DLE_STATE;					
						break;
				case FOOTER_DLE_STATE:
					if (PCReceiveByte == HEADER_DLE){
						DataReceiveState = FOOTER_ETX_STATE;	
					}
					else {
						DataReceiveState = HEADER_DLE_STATE;
						CRCIndex = 0;
					}
					break;
				case FOOTER_ETX_STATE:	
					if (PCReceiveByte == FOOTER_ETX){
						GetDataFromPCComplete = 1;
						DataReceiveState = HEADER_DLE_STATE;	
					}
					else {
						DataReceiveState = HEADER_DLE_STATE;
						CRCIndex = 0;
					}
					break;
				default:
					DataReceiveState = HEADER_DLE_STATE;	
					break;
			}
			if ((GetDataFromPCComplete == 1)  && (CRCFlag == COMMAND_STATUS_SUCCESS)){
				switch (CommandRec){
					case CMD_HANDSHAKE_PCTOMAIN:
						if (strstr(TempBuffer,"STAR")){
							PCKey[0]  = TempBuffer[4];
							PCKey[1]  = TempBuffer[5];
							PCKey[2]  = TempBuffer[6];
							PCKey[3]  = TempBuffer[7];
							MainResponseHash(PCKey);
						}
						break;
					case CMD_HANDSHAKE_PC_AUTHENTICATE:
						MainCreateHash(MainKey,MainHash);
						if (memcmp(MainHash,TempBuffer,16) == 0){
							MainResponseSuccess();
							AuthenticateFlag = 1;
							SystemMode = MAIN_PC_MODE;							
							LCDClear();
							LCDPrintStringCenter(0,"Karaoke Cosy");
							LCDPrintStringCenter(1,"System Running");
							BuzzerSound(100,100,3);
						}
						break;
					default:
						MainResponseFail();
						break;
				}
				GetDataFromPCComplete = 0;
			}
		}
	}
}
int32_t STM32_MD5_HASH_DigestCompute(uint8_t* InputMessage, uint32_t InputMessageLength,uint8_t *MessageDigest, int32_t* MessageDigestLength){
                               
	MD5ctx_stt P_pMD5ctx;
	uint32_t error_status = HASH_SUCCESS;

	/* Set the size of the desired hash digest */
	P_pMD5ctx.mTagSize = CRL_MD5_SIZE;

	/* Set flag field to default value */
	P_pMD5ctx.mFlags = E_HASH_DEFAULT;

	error_status = MD5_Init(&P_pMD5ctx);

	/* check for initialization errors */
	if (error_status == HASH_SUCCESS){
		/* Add data to be hashed */
		error_status = MD5_Append(&P_pMD5ctx,
		InputMessage,
		InputMessageLength);

		if (error_status == HASH_SUCCESS){
		/* retrieve */
			error_status = MD5_Finish(&P_pMD5ctx, MessageDigest, MessageDigestLength);
		}
	}
	return error_status;
}

uint16_t RandomNumber= 1;
// Dung ngat timer 1ms de tang dan so random. 
// Vi lay tai moi thoi diem khac nhau nen so random nay luon thay doi
void CreatTheRandomNumber(){
	RandomNumber ++;
	if (RandomNumber > 65000){
		RandomNumber = 1;
	}
}
uint16_t GetTheRandomNumber(){
	return RandomNumber;
}
uint16_t GenerateMainKey(){
	uint16_t _temp;
	_temp = GetTheRandomNumber();
	_temp =  1000 + _temp%9000;
	//_temp =  1000 + rand()%9000;
	return _temp;
}

void MainCreateHash(uint16_t mainKey,uint8_t* OutputMessage){
	int32_t status = HASH_SUCCESS;
	uint8_t Imessage[8];
	uint32_t ImessageLength;
	uint32_t HashOutputLength = 0;

	Imessage[0] = ((mainKey/1000)%10)+0x30;
	Imessage[1] = ((mainKey/100)%10)+0x30;
	Imessage[2] = ((mainKey/10)%10)+0x30;
	Imessage[3] = (mainKey%10)+0x30;
	Imessage[4] = 'C';
	Imessage[5] = 'B';
	Imessage[6] = '4';
	Imessage[7] = 'U';
	
	status = STM32_MD5_HASH_DigestCompute((uint8_t*)Imessage,8,(uint8_t*)OutputMessage,&HashOutputLength);
}

void MainResponseHash(uint8_t* pckey){
	uint8_t crcBuffer[25];
	uint16_t crcValue;
	int32_t status = HASH_SUCCESS;
	uint8_t Imessage[8];
	uint32_t ImessageLength;
	uint8_t HashOutput[16];
	uint32_t HashOutputLength = 0;
	uint8_t index = 0;
	
	Imessage[0] = pckey[0];
	Imessage[1] = pckey[1];
	Imessage[2] = pckey[2];
	Imessage[3] = pckey[3];
	Imessage[4] = 'C';
	Imessage[5] = 'B';
	Imessage[6] = '4';
	Imessage[7] = 'U';
	status = STM32_MD5_HASH_DigestCompute((uint8_t*)Imessage,8,(uint8_t*)HashOutput,&HashOutputLength);
	if (status == HASH_SUCCESS){
		MainKey = GenerateMainKey();
		//UARTPCSendString("\r\n MainKey = \t");
		//UARTPCSendNumber(MainKey);
		//UARTPCSendString("\r\n\t");
		crcBuffer[0] = ADD0;
		crcBuffer[1] = ADD1;
		crcBuffer[2] = ADD2;
		crcBuffer[3] = CMD_HANDSHAKE_MAIN_RESPONSE;
		crcBuffer[4] = 20;
		for (index = 0;index<16;index++){
			crcBuffer[5+index] =HashOutput[index] ;
		}
		crcBuffer[21] =((MainKey/1000)%10)+0x30;
		crcBuffer[22] =((MainKey/100)%10)+0x30;
		crcBuffer[23] =((MainKey/10)%10)+0x30;
		crcBuffer[24] =(MainKey%10)+0x30;
		crcValue = CalculateCRC16(crcBuffer,25);
		UARTPCSendByte(HEADER_DLE);
		UARTPCSendByte(HEADER_STX);
		UARTPCSendByte(ADD0);
		UARTPCSendByte(ADD1);
		UARTPCSendByte(ADD2);
		UARTPCSendByte(CMD_HANDSHAKE_MAIN_RESPONSE);
		UARTPCSendByte(20);
		for (index = 0;index<16;index++){
			UARTPCSendByte(HashOutput[index]);
		}
		UARTPCSendByte(((MainKey/1000)%10)+0x30);
		UARTPCSendByte(((MainKey/100)%10)+0x30);
		UARTPCSendByte(((MainKey/10)%10)+0x30);
		UARTPCSendByte((MainKey%10)+0x30);
		
		UARTPCSendByte(crcValue>>8);
		UARTPCSendByte(crcValue);					
		UARTPCSendByte(FOOTER_DLE);
		UARTPCSendByte(FOOTER_ETX);
	}
}

void MainResponseSuccess(){
	uint8_t crcBuffer[25];
	uint16_t crcValue;

	crcBuffer[0] = ADD0;
	crcBuffer[1] = ADD1;
	crcBuffer[2] = ADD2;
	crcBuffer[3] = CMD_HANDSHAKE_MAIN_AUTHENTICATE;
	crcBuffer[4] = 4;
	crcBuffer[5] = 'S';
	crcBuffer[6] = 'U';
	crcBuffer[7] = 'C';
	crcBuffer[8] = 'C';
	crcValue = CalculateCRC16(crcBuffer,9);
	UARTPCSendByte(HEADER_DLE);
	UARTPCSendByte(HEADER_STX);
	UARTPCSendByte(ADD0);
	UARTPCSendByte(ADD1);
	UARTPCSendByte(ADD2);
	UARTPCSendByte(CMD_HANDSHAKE_MAIN_AUTHENTICATE);
	UARTPCSendByte(4);
	UARTPCSendString("SUCC\t");
	UARTPCSendByte(crcValue>>8);
	UARTPCSendByte(crcValue);					
	UARTPCSendByte(FOOTER_DLE);
	UARTPCSendByte(FOOTER_ETX);
}

void MainResponseFail(){
	uint8_t crcBuffer[10];
	uint16_t crcValue;

	crcBuffer[0] = ADD0;
	crcBuffer[1] = ADD1;
	crcBuffer[2] = ADD2;
	crcBuffer[3] = CMD_HANDSHAKE_ERROR;
	crcBuffer[4] = 4;
	crcBuffer[5] = 'F';
	crcBuffer[6] = 'A';
	crcBuffer[7] = 'I';
	crcBuffer[8] = 'L';
	crcValue = CalculateCRC16(crcBuffer,9);
	UARTPCSendByte(HEADER_DLE);
	UARTPCSendByte(HEADER_STX);
	UARTPCSendByte(ADD0);
	UARTPCSendByte(ADD1);
	UARTPCSendByte(ADD2);
	UARTPCSendByte(CMD_HANDSHAKE_ERROR);
	UARTPCSendByte(4);
	UARTPCSendString("FAIL\t");
	UARTPCSendByte(crcValue>>8);
	UARTPCSendByte(crcValue);					
	UARTPCSendByte(FOOTER_DLE);
	UARTPCSendByte(FOOTER_ETX);
}

void MainResponseNotAuthenticate(uint8_t _cmd){
	uint8_t crcBuffer[7];
	uint16_t crcValue;

	crcBuffer[0] = ADD0;
	crcBuffer[1] = ADD1;
	crcBuffer[2] = ADD2;
	crcBuffer[3] = _cmd;
	crcBuffer[4] = 2;
	crcBuffer[5] = 0x03;
	crcBuffer[6] = 0x00;
	crcValue = CalculateCRC16(crcBuffer,7);
	UARTPCSendByte(HEADER_DLE);
	UARTPCSendByte(HEADER_STX);
	UARTPCSendByte(ADD0);
	UARTPCSendByte(ADD1);
	UARTPCSendByte(ADD2);
	UARTPCSendByte(_cmd);
	UARTPCSendByte(2);
	UARTPCSendByte(0x03);
	UARTPCSendByte(0x00);
	UARTPCSendByte(crcValue>>8);
	UARTPCSendByte(crcValue);					
	UARTPCSendByte(FOOTER_DLE);
	UARTPCSendByte(FOOTER_ETX);
	
}
void MainResponse(uint8_t _cmd){
	uint8_t crcBuffer[7];
	uint16_t crcValue;

	crcBuffer[0] = ADD0;
	crcBuffer[1] = ADD1;
	crcBuffer[2] = ADD2;
	crcBuffer[3] = _cmd;
	crcBuffer[4] = 2;
	crcBuffer[5] = 0x01;
	crcBuffer[6] = 0x00;
	crcValue = CalculateCRC16(crcBuffer,7);
	UARTPCSendByte(HEADER_DLE);
	UARTPCSendByte(HEADER_STX);
	UARTPCSendByte(ADD0);
	UARTPCSendByte(ADD1);
	UARTPCSendByte(ADD2);
	UARTPCSendByte(_cmd);
	UARTPCSendByte(2);
	UARTPCSendByte(0x01);
	UARTPCSendByte(0x00);
	UARTPCSendByte(crcValue>>8);
	UARTPCSendByte(crcValue);					
	UARTPCSendByte(FOOTER_DLE);
	UARTPCSendByte(FOOTER_ETX);
}
void MainResponseError(uint8_t _cmd){
	uint8_t crcBuffer[7];
	uint16_t crcValue;

	crcBuffer[0] = ADD0;
	crcBuffer[1] = ADD1;
	crcBuffer[2] = ADD2;
	crcBuffer[3] = _cmd;
	crcBuffer[4] = 2;
	crcBuffer[5] = 0xF0;
	crcBuffer[6] = 0x00;
	crcValue = CalculateCRC16(crcBuffer,7);
	UARTPCSendByte(HEADER_DLE);
	UARTPCSendByte(HEADER_STX);
	UARTPCSendByte(ADD0);
	UARTPCSendByte(ADD1);
	UARTPCSendByte(ADD2);
	UARTPCSendByte(_cmd);
	UARTPCSendByte(2);
	UARTPCSendByte(0xF0);
	UARTPCSendByte(0x00);
	UARTPCSendByte(crcValue>>8);
	UARTPCSendByte(crcValue);					
	UARTPCSendByte(FOOTER_DLE);
	UARTPCSendByte(FOOTER_ETX);
}

void GetDataFromRS485(){
	if (RS485RXAvailable()){
		UARTPCSendByte(RS485ReceiveByte());
	}
}

void SetMaxSubNode(uint8_t value){
	MaxSubNode = value;
}
uint8_t GetMaxSubNode(){
	return MaxSubNode;
}

void DisplayControlRoomManualMode(uint8_t _room, uint8_t _state){
	LCDPrintStringCenter(0,"                ");
	LCDPrintString(0,0,"Room ");
	LCDPutDigi3(5,0,_room);
	if (_state == DEVICE_OFF){
		LCDPrintString(13,0, "OFF");
	}
	else {
		LCDPrintString(13,0, " ON");
	}
}

void SendDataToSubNodeManualMode(uint8_t _room, uint8_t _state){
	uint16_t CRCValue;		
	BufferCalculateCRC[0] = ADD0;
	BufferCalculateCRC[1] = ADD1;
	BufferCalculateCRC[2] = _room;
	BufferCalculateCRC[3] = 0x82 -_state ;
	BufferCalculateCRC[4] = DATA_LENGTH_DEFAULT;
	BufferCalculateCRC[5] = 0x00;
	BufferCalculateCRC[6] = 0x03;
	CRCValue = CalculateCRC16(BufferCalculateCRC,7);	
	RS485Transmit();
	RS485SendByte(HEADER_DLE);
	RS485SendByte(HEADER_STX);
	RS485SendByte(ADD0);
	RS485SendByte(ADD1);
	RS485SendByte(_room);
	RS485SendByte(0x82 -_state);
	RS485SendByte(DATA_LENGTH_DEFAULT);
	RS485SendByte(0x00);
	RS485SendByte(0x03);
	RS485SendByte(CRCValue>>8);
	RS485SendByte(CRCValue);					
	RS485SendByte(FOOTER_DLE);
	RS485SendByte(FOOTER_ETX);
	RS485Receive();
}