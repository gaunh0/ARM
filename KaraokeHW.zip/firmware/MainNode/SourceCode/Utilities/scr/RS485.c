#include "RS485.h"

// UART Receiver buffer
#define RS485_RX_BUFFER_SIZE 200
volatile uint8_t rs485_rx_buffer[RS485_RX_BUFFER_SIZE];
volatile uint16_t rs485_rx_wr_index,rs485_rx_rd_index,rs485_rx_counter;
volatile uint8_t rs485_rx_buffer_overflow = 0;

void RS485InitController(){
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;

	/* Configure the RW_PIN */
	RCC_APB2PeriphClockCmd(RW_CLK, ENABLE);	
	GPIO_InitStructure.GPIO_Pin = RW_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(RW_PORT, &GPIO_InitStructure);

	
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
	USART_InitStructure.USART_BaudRate =115200;
	/* Enable GPIO clock */
	RCC_APB2PeriphClockCmd(UART_RS485_TX_GPIO_CLK | UART_RS485_RX_GPIO_CLK | RCC_APB2Periph_AFIO, ENABLE);
	/* Enable UART clock */
	RCC_APB2PeriphClockCmd(UART_RS485_CLK, ENABLE);

	/* Configure USART Tx as alternate function push-pull */
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin = UART_RS485_TX_PIN;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(UART_RS485_TX_GPIO_PORT, &GPIO_InitStructure);
	/* Configure USART Rx as input floating */
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Pin = UART_RS485_RX_PIN;
	GPIO_Init(UART_RS485_RX_GPIO_PORT, &GPIO_InitStructure);

	USART_Init(UART_RS485, &USART_InitStructure);
	USART_Cmd(UART_RS485, ENABLE);
	USART_ITConfig(UART_RS485,USART_IT_RXNE, ENABLE);

	
	/* Configure the NVIC Preemption Priority Bits */
	NVIC_PriorityGroupConfig(UART_PREEMPTION);
	NVIC_InitStructure.NVIC_IRQChannel = UART_RS485_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = UART_RS485_SUB_PRIORITY;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	RS485SendByte(0);
	//RS485Receive();
}
void RS485Transmit(){
	 GPIO_SetBits(RW_PORT,RW_PIN);
}

void RS485Receive(){
	GPIO_ResetBits(RW_PORT,RW_PIN);
}

void RS485SendByte(uint8_t _data){
	USART_SendData(UART_RS485, _data);
	while(USART_GetFlagStatus(UART_RS485, USART_FLAG_TC) == RESET);
}

void RS485SendChar(const char _data){	
	USART_SendData(UART_RS485, _data);
	while(USART_GetFlagStatus(UART_RS485, USART_FLAG_TC) == RESET);
}

void RS485SendString(const char *_data){
	while(*_data != '\t'){
		RS485SendChar(*_data);
		_data++;
	}
}

void RS485SendStringLength(char* data, uint16_t _length)
{
	uint8_t i=0;
	
	for (i=0; i<_length; i++)
	{
		RS485SendChar(*data);
		data++;
	}
}

void RS485SendNumber(uint16_t _number){
	if (_number >= 10000) { 	// 5 char
		RS485SendChar((_number/10000) + '0' );
		RS485SendChar(((_number/1000) % 10 )+ '0' );
		RS485SendChar(((_number/100) % 10 )+ '0' );
		RS485SendChar(((_number/10) % 10 )+ '0' );
		RS485SendChar((_number % 10 )+ '0' );
	}
	else if (_number >= 1000) { 	// 4 char
		RS485SendChar(((_number/1000))+ '0' );
		RS485SendChar(((_number/100) % 10 )+ '0' );
		RS485SendChar(((_number/10) % 10 )+ '0' );
		RS485SendChar((_number % 10 )+ '0' );
	}
	else if (_number >= 100) {	 // 3 char
		RS485SendChar(((_number/100) )+ '0' );
		RS485SendChar(((_number/10) % 10 )+ '0' );
		RS485SendChar((_number % 10 )+ '0' );
	}
	else if (_number >= 10) { 	// 2 char
		RS485SendChar(((_number/10))+ '0' );
		RS485SendChar((_number % 10 )+ '0' );
	}
	else {					// 1 char
		RS485SendChar(_number+ '0' );
	}
}

void UART_RS485_ISR(void)
{
	unsigned char _data;
	if(USART_GetITStatus(UART_RS485, USART_IT_RXNE) != RESET)
	{
		_data = USART_ReceiveData(UART_RS485);
		rs485_rx_buffer[rs485_rx_wr_index] = _data;
		if (++rs485_rx_wr_index == RS485_RX_BUFFER_SIZE) rs485_rx_wr_index = 0;
		if (++rs485_rx_counter == RS485_RX_BUFFER_SIZE)
		{
			rs485_rx_counter = 0;
			rs485_rx_buffer_overflow = 1;
		}		
	}
}

uint8_t RS485ReceiveByte(){
	uint8_t data = 0;
	if (rs485_rx_counter > 0){
		data = rs485_rx_buffer[rs485_rx_rd_index];
		if (++rs485_rx_rd_index == RS485_RX_BUFFER_SIZE) rs485_rx_rd_index=0;
		--rs485_rx_counter;
	}
	return data;
}

uint8_t RS485RXAvailable(){
	return rs485_rx_counter;
}

void RS485RXFlush(){
	while(RS485RXAvailable()){
		RS485ReceiveByte();
	}
}


