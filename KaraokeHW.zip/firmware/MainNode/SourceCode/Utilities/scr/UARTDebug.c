#include "UARTDebug.h"

// UART Receiver buffer
#define DEBUG_RX_BUFFER_SIZE 200
volatile uint8_t debug_rx_buffer[DEBUG_RX_BUFFER_SIZE];
volatile uint16_t debug_rx_wr_index,debug_rx_rd_index,debug_rx_counter;

// This flag is set on USART Receiver buffer overflow
volatile unsigned char debug_rx_buffer_overflow;

/* @brief  Configures COM port. */
void DebugInitController()
{
	/* USARTx configured as follow:
	      - BaudRate = 115200 baud
	      - Word Length = 8 Bits
	      - One Stop Bit
	      - No parity
	      - Hardware flow control disabled (RTS and CTS signals)
	      - Receive and transmit enabled
		*/

	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;


	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	//USART_InitStructure.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
	USART_InitStructure.USART_Mode = USART_Mode_Tx ;
	USART_InitStructure.USART_BaudRate =115200;
	/* Enable GPIO clock */
	RCC_APB2PeriphClockCmd(UART_DEBUG_TX_GPIO_CLK | UART_DEBUG_RX_GPIO_CLK |RCC_APB2Periph_AFIO, ENABLE);
	RCC_APB1PeriphClockCmd(UART_DEBUG_CLK, ENABLE);

	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin = UART_DEBUG_TX_PIN;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(UART_DEBUG_TX_GPIO_PORT, &GPIO_InitStructure);

	/* Configure USART Rx as input floating */
	/*GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Pin = UART_DEBUG_RX_PIN;
	GPIO_Init(UART_DEBUG_RX_GPIO_PORT, &GPIO_InitStructure);	*/
	
	
	USART_Init(UART_DEBUG, &USART_InitStructure);
	USART_Cmd(UART_DEBUG, ENABLE);
	/*USART_ITConfig(UART_DEBUG,USART_IT_RXNE, ENABLE);	
	
	NVIC_PriorityGroupConfig(UART_PREEMPTION);
	NVIC_InitStructure.NVIC_IRQChannel = UART_DEBUG_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = UART_DEBUG_SUB_PRIORITY;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);*/
}


void UART_DEBUG_ISR(void)
{
	uint8_t data;
	if(USART_GetITStatus(UART_DEBUG, USART_IT_RXNE) != RESET)
	{
		data = USART_ReceiveData(UART_DEBUG);
		//RS485SendByte(data);
		debug_rx_buffer[debug_rx_wr_index] = data;
		if (++debug_rx_wr_index == DEBUG_RX_BUFFER_SIZE) debug_rx_wr_index = 0;
		if (++debug_rx_counter == DEBUG_RX_BUFFER_SIZE)
		{
			debug_rx_counter = 0;
		}
	}
}

void DebugSendByte(uint8_t _data){
	USART_SendData(UART_DEBUG, _data);
	while(USART_GetFlagStatus(UART_DEBUG, USART_FLAG_TC) == RESET);
}

void DebugSendChar(const char _data){	
	USART_SendData(UART_DEBUG, _data);
	while(USART_GetFlagStatus(UART_DEBUG, USART_FLAG_TC) == RESET);
}

void DebugSendString(const char *_data){
	while(*_data != '\t')
	{
		DebugSendChar(*_data);
		_data++;
	}
}

void DebugSendStringLength(char* data, uint16_t _length)
{
	uint8_t i=0;
	for (i=0; i<_length; i++)
	{
		DebugSendChar(*data);
		data++;
	}
}

void DebugSendNumber(uint16_t _number){
	if (_number >= 10000) { 	// 5 char
		DebugSendChar((_number/10000) + '0' );
		DebugSendChar(((_number/1000) % 10 )+ '0' );
		DebugSendChar(((_number/100) % 10 )+ '0' );
		DebugSendChar(((_number/10) % 10 )+ '0' );
		DebugSendChar((_number % 10 )+ '0' );
	}
	else if (_number >= 1000) { 	// 4 char
		DebugSendChar(((_number/1000))+ '0' );
		DebugSendChar(((_number/100) % 10 )+ '0' );
		DebugSendChar(((_number/10) % 10 )+ '0' );
		DebugSendChar((_number % 10 )+ '0' );
	}
	else if (_number >= 100) {	 // 3 char
		DebugSendChar(((_number/100) )+ '0' );
		DebugSendChar(((_number/10) % 10 )+ '0' );
		DebugSendChar((_number % 10 )+ '0' );
	}
	else if (_number >= 10) { 	// 2 char
		DebugSendChar(((_number/10))+ '0' );
		DebugSendChar((_number % 10 )+ '0' );
	}
	else {					// 1 char
		DebugSendChar(_number+ '0' );
	}
}


uint8_t DebugReceivedByte(void)
{
	uint8_t data = 0;
	if (debug_rx_counter > 0){
		data = debug_rx_buffer[debug_rx_rd_index];
		if (++debug_rx_rd_index == DEBUG_RX_BUFFER_SIZE) debug_rx_rd_index=0;
		debug_rx_counter--;
	}
	return data;
}
uint8_t DebugRXAvailable(void)
{
	return debug_rx_counter;
}


