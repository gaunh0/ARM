#include "Ultility.h"
#include <string.h>


#define CRC16_IBM		0x8005		// ModBus, USB, Bisync, CRC-16, CRC-16-ANSI, ...
#define POLYNOM		CRC16_IBM

uint8_t GetFirstPositionCharOccur(uint8_t* _str,uint8_t _char){
	uint8_t* ptr_temp;
	ptr_temp = strchr(_str,_char);
	return ((ptr_temp-_str)); // count from ZERO
}

uint8_t GetLastPositionCharOccur(uint8_t* _str,uint8_t _char){
	uint8_t* ptr_temp;
	ptr_temp = strrchr(_str,_char);
	return ((ptr_temp-_str)); // count from ZERO
}

uint8_t GetIndexString(uint8_t* _source,uint8_t* _sample){
	uint8_t* ptr_temp;
	uint8_t ret_val = 0;	
	ptr_temp = strstr(_source,_sample);
	ret_val = (ptr_temp - _source);  // count from ZERO
	return ret_val; 
}

uint8_t GetIndexAfterString(uint8_t* _source,uint8_t* _sample){
	uint8_t* ptr_temp;
	uint8_t ret_val = 0;	
	ptr_temp = strstr(_source,_sample);
	ret_val = (ptr_temp - _source) + strlen (_sample);  // count from ZERO
	return ret_val; 
}

uint16_t CRC16Update(uint16_t crc, uint8_t data){
	uint8_t i;
	for (i = 0; i < 8; i++) {
		if (((crc & 0x8000) >> 8 ) ^ (data & 0x80)){
			crc = (crc << 1) ^ POLYNOM;
		}
		else{
			crc = (crc << 1);
		}
		data <<= 1;
	}
	return crc;
}
uint16_t CalculateCRC16(uint8_t *data, uint8_t len){
	uint16_t crc;
	uint8_t i = 0; 
	// CRC Initialization
	crc = 0x0000;
	while (i < len){
		crc = CRC16Update(crc, data[i]);
		i++;
	}
	return crc;
}

uint8_t FindNumber(uint8_t* source, uint8_t sourceLength,uint8_t value){
	uint8_t index;
	for (index = 0; index < sourceLength; index++){
		if (source[index] == value){
			return index;
		}			
	}
}

