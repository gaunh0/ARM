#include "Buzzer.h" 
///the remain time that Buzzer will keep ON state
uint16_t currentBuzzerOnPeriod;
///the remain time that Buzzer will keep OFF state
uint16_t currentBuzzerOffPeriod;
///the Period that Buzzer will be ON at each cycle
uint16_t BuzzerOnPeriod;///the Period that Buzzer will be OFF at each cycle
uint16_t BuzzerOffPeriod;///the remain number of Buzzer Cycle
uint8_t NumberOfBuzzerCycle;///Current state of Buzzer: ON or OFF
uint8_t BuzzerState = BUZZER_OFF;

void BuzzerInitController(void){
	GPIO_InitTypeDef GPIO_InitStructure;

	/* Enable the GPIO_Clock */ 
	RCC_APB2PeriphClockCmd(BUZZER_CLK, ENABLE);
	
	GPIO_InitStructure.GPIO_Pin = BUZZER_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(BUZZER_PORT, &GPIO_InitStructure);	
	BuzzerOff();
	TurnOffBuzzer();
}

void BuzzerOn(){
	GPIO_SetBits(BUZZER_PORT,BUZZER_PIN);
	BuzzerState = BUZZER_ON;
}

void BuzzerOff(){
	GPIO_ResetBits(BUZZER_PORT,BUZZER_PIN);
	BuzzerState = BUZZER_OFF;
}

void TurnOffBuzzer(){
	BuzzerSound(0,0,0);
}

void BuzzerSound(uint16_t OnPeriod, uint16_t OffPeriod, uint8_t Time){    
	BuzzerOnPeriod = OnPeriod;    
	currentBuzzerOnPeriod =  OnPeriod;    
	BuzzerOffPeriod = OffPeriod;    
	currentBuzzerOffPeriod = OffPeriod;    
	NumberOfBuzzerCycle = Time;	
	BuzzerState = BUZZER_ON;
}

void BuzzerService(){    
	if (NumberOfBuzzerCycle == 0) {        
		BuzzerOff();
	}
	else if (BuzzerState == BUZZER_ON){
		BuzzerOn();   
		if (currentBuzzerOnPeriod>0) {	
			currentBuzzerOnPeriod--;
		}
		else if (currentBuzzerOnPeriod == 0){    
			NumberOfBuzzerCycle--;   
			currentBuzzerOnPeriod = BuzzerOnPeriod;	            
			BuzzerOff();       
		}   
	}	   
	else { 
		BuzzerOff();  
		if (currentBuzzerOffPeriod>0){ 	
			currentBuzzerOffPeriod--;	
		}
		else if (currentBuzzerOffPeriod == 0){    
			currentBuzzerOffPeriod = BuzzerOffPeriod;	            
			BuzzerOn();       
		}    
	}	
}

