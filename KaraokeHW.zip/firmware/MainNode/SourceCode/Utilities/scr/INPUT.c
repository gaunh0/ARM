#include "Input.h"
#include "Buzzer.h"

uint8_t InputValue[4] = {0,0,0,0};

void InputInitController(){
	GPIO_InitTypeDef  GPIO_InitStructure;

	/* Configure the Mode Switch */
	RCC_APB2PeriphClockCmd(SWITCH_CLK , ENABLE);	
	GPIO_InitStructure.GPIO_Pin = SWITCH_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(SWITCH_PORT, &GPIO_InitStructure);
	
	/* Configure the KEY1_PIN */
	RCC_APB2PeriphClockCmd(BUTTON1_CLK , ENABLE);	
	GPIO_InitStructure.GPIO_Pin = BUTTON1_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(BUTTON1_PORT, &GPIO_InitStructure);

	/* Configure the KEY1_PIN */
	RCC_APB2PeriphClockCmd(BUTTON2_CLK , ENABLE);	
	GPIO_InitStructure.GPIO_Pin = BUTTON2_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(BUTTON2_PORT, &GPIO_InitStructure);

	/* Configure the KEY1_PIN */
	RCC_APB2PeriphClockCmd(BUTTON3_CLK , ENABLE);	
	GPIO_InitStructure.GPIO_Pin = BUTTON3_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(BUTTON3_PORT, &GPIO_InitStructure);
}

uint8_t timer_cnt = 0;
void InputService(){
	if (timer_cnt > 10){
		if (GPIO_ReadInputDataBit(SWITCH_PORT, SWITCH_PIN)  == Bit_RESET){				
			InputValue[3] |= SWITCH_MASK;
		}	
		else {
			InputValue[3] &= ~SWITCH_MASK;
		}		
		if (GPIO_ReadInputDataBit(BUTTON1_PORT, BUTTON1_PIN)  == Bit_RESET){	
			InputValue[3] |= BUTTON1_MASK;
		}	
		else {
			InputValue[3] &= ~BUTTON1_MASK;
		}
		if (GPIO_ReadInputDataBit(BUTTON2_PORT, BUTTON2_PIN)  == Bit_RESET){	
			InputValue[3] |= BUTTON2_MASK;
		}	
		else {
			InputValue[3] &= ~BUTTON2_MASK;
		}
		if (GPIO_ReadInputDataBit(BUTTON3_PORT, BUTTON3_PIN)  == Bit_RESET){	
			InputValue[3] |= BUTTON3_MASK;
		}	
		else {
			InputValue[3] &= ~BUTTON3_MASK;
		}
		
	        InputValue[1] = InputValue[2];
	        InputValue[2] = InputValue[3];
	        if ((InputValue[1] == InputValue[2])&&(InputValue[2] == InputValue[3])){
			InputValue[0] = InputValue[3];
	        }	
	        timer_cnt = 0;
	}
	else {
		timer_cnt ++;
	}
}


uint8_t GetInputValue(){
	return InputValue[0] ;
}

uint8_t GetSwitchModeValue(){
	if ((InputValue[0] & SWITCH_MASK) == SWITCH_MASK){
		return HIGH_STATE;
	}
	else return LOW_STATE;
}

uint8_t PressUP(){
	if ((GetInputValue() & BUTTON2_MASK) == BUTTON2_MASK){
		return 1;
	}
	else return 0;
}

uint8_t PressDOWN(){
	if ((GetInputValue() & BUTTON3_MASK) == BUTTON3_MASK){
		return 1;
	}
	else return 0;
}


uint8_t PressSELECT(){
	if ((GetInputValue() & BUTTON1_MASK) == BUTTON1_MASK){
		return 1;
	}
	else return 0;
}

