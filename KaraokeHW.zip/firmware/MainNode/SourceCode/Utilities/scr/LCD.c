#include "LCD.h"

void LCDInitController(){

	GPIO_InitTypeDef  GPIO_InitStructure;

	RCC_APB2PeriphClockCmd(LCD_CTRL_CLK, ENABLE);	

	/* Configure the LCD_CTRL_PIN is output */
	GPIO_InitStructure.GPIO_Pin =  LCD_RS_PIN|LCD_RD_PIN|LCD_EN_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(LCD_CTRL_PORT, &GPIO_InitStructure);	

	RCC_APB2PeriphClockCmd(LCD_DATA_CLK, ENABLE);
	/* Configure the LCD_DATA_PIN is output */
	GPIO_InitStructure.GPIO_Pin = LCD_D5_PIN | LCD_D6_PIN| LCD_D7_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(LCD_DATA_PORT, &GPIO_InitStructure);	
	
	RCC_APB2PeriphClockCmd(LCD_CTRL_CLK|LCD_DATA_CLK|RCC_APB2Periph_AFIO, ENABLE);
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);	
	
	GPIO_InitStructure.GPIO_Pin =  LCD_D4_PIN | LCD_BL_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(LCD_CTRL_PORT, &GPIO_InitStructure);	

	GPIO_SetBits(LCD_CTRL_PORT,LCD_BL_PIN);
	
	LCD_EN_PIN_LOW();
	LCDSetWriteMode();
	LCDSetCommandMode();
	
	DelayMs(16);			//wait for more than 15ms
	LCDWrite4Bit(0x03);    // Select 4-bit interface          
	DelayMs(16);			//wait for more than 15ms
	LCDWrite4Bit(0x03);
	DelayMs(16);			//wait for more than 15ms
	LCDWrite4Bit(0x03);  
	DelayMs(16);			//wait for more than 15ms
	LCDWrite4Bit(0x02);	//Start operation in 4-bit mode
	DelayMs(16);			//wait for more than 15ms
	LCDWriteCommand(0x28);  // 2 lines, 5x7 character matrix      
	DelayMs(16);			//wait for more than 15ms
	LCDWriteCommand(0x0C);  // Display ctrl:Disp=ON,Curs/Blnk=ON 
	DelayMs(16);			//wait for more than 15ms
	LCDWriteCommand(0x00);  // Entry mode: Move right, no shift   
	DelayMs(16);			//wait for more than 15ms		   
	
	LCDClear();
	
}

void LCDSetDataPortOutput(){
	GPIO_InitTypeDef  GPIO_InitStructure;
	/* Configure the LCD_DATA_PIN is output */
	GPIO_InitStructure.GPIO_Pin = LCD_D4_PIN | LCD_D5_PIN | LCD_D6_PIN| LCD_D7_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(LCD_DATA_PORT, &GPIO_InitStructure);	

}
void LCDSetDataPortInput(){
	
	GPIO_InitTypeDef  GPIO_InitStructure;
	/* Configure the LCD_DATA_PIN is input */
	GPIO_InitStructure.GPIO_Pin = LCD_D4_PIN | LCD_D5_PIN | LCD_D6_PIN| LCD_D7_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(LCD_DATA_PORT, &GPIO_InitStructure);	
}

void LCDSetDataOutput(uint8_t _data){
	if ((_data & 0x01) == 0x01){
		GPIO_SetBits(LCD_DATA_PORT,LCD_D4_PIN);
	}
	else {
		GPIO_ResetBits(LCD_DATA_PORT,LCD_D4_PIN);
	}
	if ((_data & 0x02) == 0x02){
		GPIO_SetBits(LCD_DATA_PORT,LCD_D5_PIN);
	}
	else {
		GPIO_ResetBits(LCD_DATA_PORT,LCD_D5_PIN);
	}
	if ((_data & 0x04) == 0x04){
		GPIO_SetBits(LCD_DATA_PORT,LCD_D6_PIN);
	}
	else {
		GPIO_ResetBits(LCD_DATA_PORT,LCD_D6_PIN);
	}
	if ((_data & 0x08) == 0x08){
		GPIO_SetBits(LCD_DATA_PORT,LCD_D7_PIN);
	}
	else {
		GPIO_ResetBits(LCD_DATA_PORT,LCD_D7_PIN);
	}
}


void LCDSetDataMode(){
	GPIO_SetBits(LCD_CTRL_PORT,LCD_RS_PIN);
}
void LCDSetCommandMode(){  
	GPIO_ResetBits(LCD_CTRL_PORT,LCD_RS_PIN);
}
void LCDSetReadMode(){
	GPIO_SetBits(LCD_CTRL_PORT,LCD_RD_PIN);
}
void LCDSetWriteMode(){
	GPIO_ResetBits(LCD_CTRL_PORT,LCD_RD_PIN);
}
void LCD_EN_PIN_LOW(){
	GPIO_ResetBits(LCD_CTRL_PORT,LCD_EN_PIN);
}
void LCD_EN_PIN_HIGH(){
	GPIO_SetBits(LCD_CTRL_PORT,LCD_EN_PIN);
}

void LCDWrite4Bit(uint8_t data){
	LCDSetWriteMode();	//keo chan RW xuong 0
	LCDSetDataOutput(data);
	LCD_EN_PIN_HIGH();		//Set chan LCD_EN_PIN len 1
	DelayMs(1);
	LCD_EN_PIN_LOW();		//Keo chan LCD_EN_PIN xuong 0
}	
void LCDWriteCommand(uint8_t cmd){
	LCDWaitBusy();
	LCDSetCommandMode();
	LCDWrite4Bit(cmd>>4);
	LCDWrite4Bit(cmd);
}
void LCDWriteData(uint8_t data){
	LCDWaitBusy();
	LCD_EN_PIN_HIGH();
	LCDSetDataMode();
	LCDWrite4Bit(data>>4);
	LCDWrite4Bit(data);
	LCDSetCommandMode();
	LCD_EN_PIN_LOW();
}
uint8_t LCDReadStatus(){
	uint8_t status = 0;
	LCDSetCommandMode();
	LCDSetReadMode();	
	LCDSetDataPortInput();
	DelayMs(1);
	//LCDDelay(10);
	LCD_EN_PIN_HIGH();
	status  = GPIO_ReadInputDataBit(LCD_DATA_PORT,LCD_D7_PIN);
	status = status << 1;
	status |= GPIO_ReadInputDataBit(LCD_DATA_PORT,LCD_D6_PIN);
	status = status << 1;	
	status |= GPIO_ReadInputDataBit(LCD_DATA_PORT,LCD_D5_PIN);
	status = status << 1;
	status |= GPIO_ReadInputDataBit(LCD_DATA_PORT,LCD_D4_PIN);
	status = status << 1;
	LCD_EN_PIN_LOW();
	LCD_EN_PIN_HIGH();
	status |= GPIO_ReadInputDataBit(LCD_DATA_PORT,LCD_D7_PIN);
	status = status << 1;
	status |= GPIO_ReadInputDataBit(LCD_DATA_PORT,LCD_D6_PIN);
	status = status << 1;
	status |= GPIO_ReadInputDataBit(LCD_DATA_PORT,LCD_D5_PIN);
	status = status << 1;
	status |= GPIO_ReadInputDataBit(LCD_DATA_PORT,LCD_D4_PIN);
	LCD_EN_PIN_LOW();
	LCDSetDataPortOutput();
	return (status);
}

uint8_t LCDWaitBusy(){
	uint8_t status=0,wait_counter=0;
	do  {
		status = LCDReadStatus();
		wait_counter++;
	} 
	while (((status & 0x80) ==0x80) && (wait_counter < 10));             /* Wait for busy flag                 */
	return (status);
}
void LCDClear (void) {
	LCDWriteCommand(0x01);                  /* Display clear                      */
	LCDWriteCommand(0x02);                  /* Display home                      */
}

void LCDDelay(uint32_t cnt){
	uint32_t temp=0;
	temp = cnt*100;
 	while (temp--);
}

void LCDCreateChar(uint8_t location, uint8_t* charmap) {
	uint8_t _i;
  location &= 0x7; // we only have 8 locations 0-7
  LCDWriteCommand(0x40 | (location << 3));
  for (_i=0; _i<8; _i++) {
    LCDWriteData(charmap[_i]);
  }
}

/*********************************************************************//**
 * @brief 		Goto coordinate cursor on Digit LC
 * @param[in] 	Column and row value
 * 				- Column : 0 -> 15
 * 				- Row	: 0 -> 1
 * @return 		None
 ***********************************************************************/
void LCDGotoXY(uint8_t col,uint8_t row)
{
	uint8_t address;
	col=col%16;
	if (row == 1){
		address = 0x80 |((row * 0x40) + col);
	}
	else {
		address = 0x80 | col;
	}
	LCDWriteCommand(address);               /* Set DDRAM address counter to 0     */
}

void LCDScrollLeft(){
	LCDWriteCommand(LCD_CURSORSHIFT | LCD_DISPLAYMOVE | LCD_MOVELEFT);
}

void LCDScrollRight(){
	LCDWriteCommand(LCD_CURSORSHIFT | LCD_DISPLAYMOVE | LCD_MOVERIGHT);
}

// Turn on and off the blinking cursor
void LCDBlink(uint8_t _state) {
	if (_state == DISABLE){
		LCDWriteCommand(0x0C);
	}
	else {
		LCDWriteCommand(0x0D);
	}
}


/*********************************************************************//**
 * @brief 		Write a byte to LCD
 * @param[in] 	Value of byte want to write, value is a unsigned byte.
 * @return 		None
 ***********************************************************************/
void LCDPutChar(uint8_t c)
{
	LCDWriteData(c);
}

/*********************************************************************//**
 * @brief 		Goto coordinate cursor on Digit LCD, and write a three digit number
 * @param[in] 	Column , row and number value, should be:
 * 				- Column : 0 -> 15
 * 				- Row	: 0 -> 1
 *				- number is a signed integer number
 * @return 		None
 ***********************************************************************/
void LCDPutDigi3(uint8_t X, uint8_t Y, int number){
	LCDGotoXY(X, Y);
/*	if (number<0){
		LCDPutChar('-'); // dau -
		number = -number;
	} else {
		LCDPutChar('+');
	}*/
	LCDPutChar('0' +(number%1000)/100);
	LCDPutChar('0' + (number%100)/10);
	LCDPutChar('0' + (number%10));		
}

/*********************************************************************//**
 * @brief 		Goto coordinate cursor on Digit LCD, and write a four digit number
 * @param[in] 	Column , row and number value, should be:
 * 				- Column : 0 -> 15
 * 				- Row	: 0 -> 1
 *				- number is a signed integer number
 * @return 		None
 ***********************************************************************/
void LCDPutDigi4(uint8_t X, uint8_t Y, int number){	
	LCDGotoXY(X, Y);
	if (number<0){
		LCDPutChar('-'); // dau -
		number = -number;
	} else {
		LCDPutChar('+');
	}
	LCDPutChar('0' + (number%10000)/1000);
	LCDPutChar('0' + (number%1000)/100);
	LCDPutChar('0' + (number%100)/10);
	LCDPutChar('0' + (number%10));		
}

/*********************************************************************//**
 * @brief 		Goto coordinate cursor on Digit LCD, and write a five digit number
 * @param[in] 	Column , row and number value, should be:
 * 				- Column : 0 -> 15
 * 				- Row	: 0 -> 1
 *				- number is a signed integer number 
 * @return 		None
 ***********************************************************************/
void LCDPutDigi5(uint8_t X, uint8_t Y,int number){	
	LCDGotoXY(X, Y);
	if (number<0){
		LCDPutChar('-'); // dau -
		number = -number;
	} else {
		LCDPutChar('+');
	}
	LCDPutChar('0' + (number%100000)/10000);
	LCDPutChar('0' + (number%10000)/1000);
	LCDPutChar('0' + (number%1000)/100);
	LCDPutChar('0' + (number%100)/10);
	LCDPutChar('0' + (number%10));		
}

/*********************************************************************//**
 * @brief 		Goto coordinate cursor on Digit LCD, and write a byte
 * @param[in] 	Column , row and number value, should be:
 * 				- Column : 0 -> 15
 * 				- Row	: 0 -> 1
 *				- number is an uint8_t number
 * @return 		None
 ***********************************************************************/
void LCDPrintChar (uint8_t column, uint8_t row, uint8_t val)
{
	LCDGotoXY(column, row);
	LCDPutChar(val);
}

/*********************************************************************//**
 * @brief 		Goto coordinate cursor on Digit LCD, and write a string
 * @param[in] 	Column , row and number value
 * 				- Column : 0 -> 15
 * 				- Row	: 0 -> 1
 *				- String of character
 * @return 		None
 ***********************************************************************/
void LCDPrintString (uint8_t column, uint8_t row, char* ptr)
{
	LCDGotoXY(column,row);
	while( *ptr != 0 ) 
	{
		LCDPutChar( *ptr );
		ptr ++;
	}
}
void LCDPrintStringCenter(uint8_t row, char* ptr){
	LCDPrintString((16 - strlen(ptr))/2,row,ptr);
}
void LCDPrintTime(uint8_t column, uint8_t row,uint32_t time){
	LCDGotoXY(column,row);
	if (time >= 10000){
		LCDPutChar(time/10000 + '0');
		LCDPutChar(((time/1000)%10) + '0');
		LCDPutChar('.');
		LCDPutChar(((time/100)%10) + '0');
		LCDPutChar('S');
	}
	else {
		LCDPutChar(time/1000 + '0');
		LCDPutChar('.');
		LCDPutChar(((time/100)%10) + '0');
		LCDPutChar(((time/10)%10) + '0');
		LCDPutChar('S');
	}
}
/*********************************************************************//**
 * @brief 		Goto coordinate cursor on Digit LCD, and write a limit quantity digits number 
 * @param[in] 	Column , row and number , quantity value,should be:
 * 				- Column : 0 -> 15
 * 				- Row	: 0 -> 1
 *				- number : is an integer number
 *				- quantity : quantity digit of number
 * @return 		None
 ***********************************************************************/
void LCDPrintNumber (uint8_t x, uint8_t y, uint16_t number, uint8_t quantity)
{
	uint16_t temp ;
	uint8_t index = 0;
	uint8_t x1 =x;
	uint8_t tempArray [12] = {0,0,0,0,0,0,0,0,0,0,0,0}; 	
	temp = number;
	while (temp != 0)
	{
		index ++;
		tempArray[index] = temp % 10;
		temp = temp / 10;
	}
	index = quantity % 16;
	while (index>=1)
	{
		LCDPrintChar(x1, y, tempArray[index] +'0');
		index --;
		x1 = x1 + 1;
	};
}

