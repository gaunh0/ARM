#include "PCCommunicate.h"

// UART Receiver buffer
#define PC_RX_BUFFER_SIZE 200
volatile uint8_t pc_rx_buffer[PC_RX_BUFFER_SIZE];
volatile uint8_t pc_rx_wr_index,pc_rx_rd_index,pc_rx_counter;

// This flag is set on USART Receiver buffer overflow
volatile unsigned char pc_rx_buffer_overflow;

void PCCommunicateInitController()
{
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;

	/* Enable GPIO clock */
	RCC_APB2PeriphClockCmd(UART_PC_TX_GPIO_CLK |UART_PC_RX_GPIO_CLK | RCC_APB2Periph_AFIO, ENABLE);
	/* Enable UART clock */
	RCC_APB1PeriphClockCmd(UART_PC_CLK, ENABLE);
	
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits = USART_StopBits_1;
	USART_InitStructure.USART_Parity = USART_Parity_No;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	USART_InitStructure.USART_BaudRate =115200;
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Pin = UART_PC_TX_PIN;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(UART_PC_TX_GPIO_PORT, &GPIO_InitStructure);
	/* Configure USART Rx as input floating */
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Pin = UART_PC_RX_PIN;
	GPIO_Init(UART_PC_RX_GPIO_PORT, &GPIO_InitStructure);	

	USART_Init(UART_PC, &USART_InitStructure);
	USART_Cmd(UART_PC, ENABLE);
	USART_ITConfig(UART_PC,USART_IT_RXNE, ENABLE);	
	
	NVIC_PriorityGroupConfig(UART_PREEMPTION);
	NVIC_InitStructure.NVIC_IRQChannel = UART_PC_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = UART_PC_SUB_PRIORITY;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

}


void UART_PC_ISR(void)
{
	unsigned char data;
	if(USART_GetITStatus(UART_PC, USART_IT_RXNE) != RESET)
	{
		data = USART_ReceiveData(UART_PC);
		pc_rx_buffer[pc_rx_wr_index] = data;
		if (++pc_rx_wr_index == PC_RX_BUFFER_SIZE) pc_rx_wr_index = 0;
		if (++pc_rx_counter == PC_RX_BUFFER_SIZE)
		{
			pc_rx_counter = 0;
			pc_rx_buffer_overflow = 1;
		}
	}
}

void UARTPCSendByte(unsigned char data)
{
	USART_SendData(UART_PC, data);
	while(USART_GetFlagStatus(UART_PC, USART_FLAG_TC) == RESET);
}

void UARTPCSendChar(const char data)
{
	USART_SendData(UART_PC, data);
	while(USART_GetFlagStatus(UART_PC, USART_FLAG_TC) == RESET);
}

void UARTPCSendString(const char *data)
{
	while(*data != '\t')
	{
		UARTPCSendChar(*data);
		data++;
	}
}

void UARTPCSendString_Length(const char* data, uint16_t _length)
{
	uint8_t i=0;
	for (i=0; i<_length; i++)
	{
		UARTPCSendChar(*data);
		data++;
	}
}

void UARTPCSendNumber(uint16_t _number){
	if (_number >= 10000) { 	// 5 char
		UARTPCSendChar((_number/10000) + '0' );
		UARTPCSendChar(((_number/1000) % 10 )+ '0' );
		UARTPCSendChar(((_number/100) % 10 )+ '0' );
		UARTPCSendChar(((_number/10) % 10 )+ '0' );
		UARTPCSendChar((_number % 10 )+ '0' );
	}
	else if (_number >= 1000) { 	// 4 char
		UARTPCSendChar(((_number/1000))+ '0' );
		UARTPCSendChar(((_number/100) % 10 )+ '0' );
		UARTPCSendChar(((_number/10) % 10 )+ '0' );
		UARTPCSendChar((_number % 10 )+ '0' );
	}
	else if (_number >= 100) {	 // 3 char
		UARTPCSendChar(((_number/100) )+ '0' );
		UARTPCSendChar(((_number/10) % 10 )+ '0' );
		UARTPCSendChar((_number % 10 )+ '0' );
	}
	else if (_number >= 10) { 	// 2 char
		UARTPCSendChar(((_number/10))+ '0' );
		UARTPCSendChar((_number % 10 )+ '0' );
	}
	else {					// 1 char
		UARTPCSendChar(_number+ '0' );
	}
}

uint8_t UARTPCReceivedByte(void)
{
	uint8_t data = 0;
	if (pc_rx_counter > 0){
		data = pc_rx_buffer[pc_rx_rd_index];
		if (++pc_rx_rd_index == PC_RX_BUFFER_SIZE) pc_rx_rd_index=0;
		pc_rx_counter--;
	}
	return data;
}


void UARTPCReceivedString(uint8_t *data_buff, uint8_t data_len)
{
	uint8_t i;
	for(i=0; i<data_len; i++)
	{
		data_buff[i] = UARTPCReceivedByte();
	}
}

uint8_t UARTPCRXAvailable(void)
{
	return pc_rx_counter;
}

void UARTPCRXClearBuffer(void)
{
	uint16_t index;
	for (index=0;index<PC_RX_BUFFER_SIZE;index++){
		pc_rx_buffer[index] = 0;
	}
	pc_rx_buffer_overflow = 0;
	pc_rx_wr_index = 0;
	pc_rx_rd_index = 0;
	pc_rx_counter = 0;
}

