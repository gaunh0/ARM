#include "FLASH.h"

uint8_t SaveNumberRoomConfig(uint32_t _value)
{
	uint32_t Address = 0x00;  
	volatile FLASH_Status FLASHStatus = FLASH_COMPLETE;
	volatile uint8_t MemoryProgramStatus = PASSED;

	/* Unlock the Flash Bank1 Program Erase controller */
	FLASH_UnlockBank1();

	/* Clear All pending flags */
	FLASH_ClearFlag(FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPRTERR);

	/* Erase the FLASH pages */
	FLASHStatus = FLASH_ErasePage(BANK1_WRITE_START_ADDR + (FLASH_PAGE_SIZE * ADDRESS_PAGE));

	/* Program Flash Bank1 */
	Address = BANK1_WRITE_START_ADDR + (FLASH_PAGE_SIZE * ADDRESS_PAGE);
	FLASHStatus = FLASH_ProgramWord(Address,_value);

	FLASH_LockBank1();

	/* Check the correctness of written data */
	Address = BANK1_WRITE_START_ADDR + (FLASH_PAGE_SIZE * ADDRESS_PAGE);
	if((*(__IO uint32_t*) Address) != _value)
	{
		MemoryProgramStatus = FAILED;
	}

	return MemoryProgramStatus;
}

uint32_t LoadNumberRoomConfig()
{
	uint32_t Address = 0x00;
	volatile FLASH_Status FLASHStatus = FLASH_COMPLETE;
	volatile uint8_t MemoryProgramStatus = PASSED;
	uint32_t ret_val = 0;

	/* Clear All pending flags */
	FLASH_ClearFlag(FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPRTERR);

	/* Check the correctness of written data */
	Address = BANK1_WRITE_START_ADDR + (FLASH_PAGE_SIZE * ADDRESS_PAGE);
	ret_val = *(__IO uint32_t*) Address;

	return ret_val;
}


