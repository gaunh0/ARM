#ifndef __VTIMER__
#define __VTIMER__

#include "main.h"
#include <stm32f10x.h>

/**
* @addtogroup	VTimerControllerDefine Virtual Timer Define Operation
* @ingroup		VTimerController
* @{
*/
#define NUMBER_OF_VIR_TIMER 		12
/**
 * @}
 */

/**
* @addtogroup	VTimerControllerPublic Virtual Timer Controller Public Function
* @ingroup		VTimerController
* @{
*/
void VTimerInitController(void);
uint8_t VTimerIsFired(uint8_t timerId);
uint8_t VTimerOut(uint8_t timerId);
void VTimerService(void);
uint8_t VTimerSet(uint8_t timerId, uint32_t period);
uint8_t VTimerGetID(void);
void VTimerRelease(uint8_t timerId);
void DelayMs(uint32_t ms);
int32_t VTimerGetTimerPeriod(uint8_t timerId);
/**
 * @}
 */

#endif

