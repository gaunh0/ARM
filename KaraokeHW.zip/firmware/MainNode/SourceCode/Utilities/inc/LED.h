#ifndef _LED_H
#define _LED_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
#include "main.h"

#define LED_PIN		GPIO_Pin_15
#define LED_PORT		GPIOB
#define LED_CLK		RCC_APB2Periph_GPIOB

void LedInitController(void);
void LedOn(void);
void LedOff(void);
void LedToggle(void);

#endif

