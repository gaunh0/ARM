#ifndef _UART_H
#define _UART_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
#include <stdio.h>
#include "main.h"


/*
* @brief Definition for COM port DEBUG, connected to USART3
 */

#define UART_DEBUG                       		USART3
#define UART_DEBUG_CLK                   	 	RCC_APB1Periph_USART3
#define UART_DEBUG_TX_PIN                 	GPIO_Pin_10
#define UART_DEBUG_TX_GPIO_PORT       	GPIOB
#define UART_DEBUG_TX_GPIO_CLK          	RCC_APB2Periph_GPIOB
#define UART_DEBUG_RX_PIN                	GPIO_Pin_11
#define UART_DEBUG_RX_GPIO_PORT      	GPIOB
#define UART_DEBUG_RX_GPIO_CLK        	RCC_APB2Periph_GPIOB
#define UART_DEBUG_IRQn                  	 	USART3_IRQn

void DebugInitController(void);
void UART_DEBUG_ISR(void);
void DebugSendByte(uint8_t _data);
void DebugSendChar(const char _data);
void DebugSendString(const char *_data);
void DebugSendStringLength(char* data, uint16_t _length);
void DebugSendNumber(uint16_t _number);
uint8_t DebugReceivedByte(void);
uint8_t DebugRXAvailable(void);
	
#endif

