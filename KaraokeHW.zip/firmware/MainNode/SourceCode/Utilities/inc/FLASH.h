#ifndef _FLASH_H
#define _FLASH_H

#include "stm32f10x.h"
#include "main.h"

#define FLASH_PAGE_SIZE    ((uint16_t)0x400)
#define BANK1_WRITE_START_ADDR  ((uint32_t)0x0800F400)
#define BANK1_WRITE_END_ADDR    ((uint32_t)0x0800FC00)

#define NUMBER_PAGE_USE			1

#define ADDRESS_PAGE				0

#define FAILED	0 
#define PASSED	1	

uint8_t SaveNumberRoomConfig(uint32_t time);
uint32_t LoadNumberRoomConfig(void);
#endif


