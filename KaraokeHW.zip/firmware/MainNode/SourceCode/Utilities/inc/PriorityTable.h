#ifndef PRIORITY_TABLE_H
#define PRIORITY_TABLE_H

//PREEMPTION
#define 	EXTI_PREEMPTION				NVIC_PriorityGroup_2
#define	UART_PREEMPTION				NVIC_PriorityGroup_0
#define 	RTC_PREEMPTION					NVIC_PriorityGroup_3
#define 	I2C_DMA_PREEMPTION			NVIC_PriorityGroup_1

//SUB-PRIORITY
#define 	UART_RS485_SUB_PRIORITY		0
#define 	UART_PC_SUB_PRIORITY			1
#define 	UART_DEBUG_SUB_PRIORITY		2

#define	RTC_SUB_PRIORITY				0

#define 	I2C_DMA_SUB_PRIORITY			0

#define 	ACC_EXTI_SUB_PRIORITY			0
#endif



