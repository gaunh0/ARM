#ifndef _GSM_H
#define _GSM_H

#include "stm32f10x.h"
#include "main.h"

/*
* @brief Definition for UART port PC communicate, connected to USART2
 */
#define UART_PC						USART2
#define UART_PC_CLK                    		RCC_APB1Periph_USART2
#define UART_PC_TX_PIN                 		GPIO_Pin_2
#define UART_PC_TX_GPIO_PORT      		GPIOA
#define UART_PC_TX_GPIO_CLK        		RCC_APB2Periph_GPIOA
#define UART_PC_RX_PIN                		GPIO_Pin_3
#define UART_PC_RX_GPIO_PORT      		GPIOA
#define UART_PC_RX_GPIO_CLK        		RCC_APB2Periph_GPIOA
#define UART_PC_RTS_PIN                 		GPIO_Pin_1
#define UART_PC_RTS_GPIO_PORT      	GPIOA
#define UART_PC_RTS_GPIO_CLK        	RCC_APB2Periph_GPIOA
#define UART_PC_CTS_PIN                		GPIO_Pin_0
#define UART_PC_CTS_GPIO_PORT      	GPIOA
#define UART_PC_CTS_GPIO_CLK        	RCC_APB2Periph_GPIOA
#define UART_PC_IRQn                   		USART2_IRQn


void PCCommunicateInitController(void);
void UART_PC_ISR(void);
void UARTPCSendByte(unsigned char data);
void UARTPCSendChar(const char data);
void UARTPCSendString(const char *data);

void UARTPCSendString_Length(const char* data, uint16_t _length);
void UARTPCSendNumber(uint16_t _number);
uint8_t UARTPCReceivedByte(void);
void UARTPCReceivedString(uint8_t *data_buff, uint8_t data_len);
uint8_t UARTPCRXAvailable(void);
void UARTPCRXClearBuffer(void);

#endif


