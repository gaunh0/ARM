#ifndef _BUZZER_H
#define _BUZZER_H


#ifdef __cplusplus
 extern "C" {
#endif 

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
#include "main.h"

#ifndef BUZZER_ON
#define BUZZER_ON 	1
#endif

#ifndef BUZZER_OFF
#define BUZZER_OFF 	0
#endif

#define BUZZER_PIN             GPIO_Pin_11
#define BUZZER_PORT          GPIOA
#define BUZZER_CLK             RCC_APB2Periph_GPIOA  

void BuzzerInitController(void);
void BuzzerOn(void);
void BuzzerOff(void);
void TurnOffBuzzer(void);
void BuzzerSound(uint16_t OnPeriod, uint16_t OffPeriod, uint8_t Time); 
void BuzzerService(void);

#endif

