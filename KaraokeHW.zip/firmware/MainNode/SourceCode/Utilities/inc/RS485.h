#ifndef RS485_H
#define RS485_H

#include "stm32f10x.h"
#include "main.h"

/*
 * @brief Definition for UART  RS485,  connected to USART1
 */
#define UART_RS485					USART1
#define UART_RS485_CLK                    		RCC_APB2Periph_USART1
#define UART_RS485_TX_PIN                 	GPIO_Pin_9
#define UART_RS485_TX_GPIO_PORT      	GPIOA
#define UART_RS485_TX_GPIO_CLK        	RCC_APB2Periph_GPIOA

#define UART_RS485_RX_PIN                	GPIO_Pin_10
#define UART_RS485_RX_GPIO_PORT      	GPIOA
#define UART_RS485_RX_GPIO_CLK        	RCC_APB2Periph_GPIOA
#define UART_RS485_IRQn                   	USART1_IRQn


#define RW_PIN		GPIO_Pin_8
#define RW_PORT		GPIOA
#define RW_CLK		RCC_APB2Periph_GPIOA

#define RS485_ACK_OK		1
#define RS485_ACK_FAIL	0

void RS485InitController(void);
void RS485Transmit(void);
void RS485Receive(void);
void RS485SendByte(uint8_t _data);
void RS485SendChar(const char _data);
void RS485SendString(const char *_data);
void RS485SendStringLength(char* data, uint16_t _length);
void RS485SendNumber(uint16_t _number);
void UART_RS485_ISR(void);
uint8_t RS485ReceiveByte(void);
uint8_t RS485RXAvailable(void);
void RS485RXFlush(void);
void RS485_ResetDataReceive(void);
uint8_t RS485_GetResponseData(void);
#endif 
 
