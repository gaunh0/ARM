#ifndef _GPIO_H
#define _GPIO_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
#include "main.h"


#define SWITCH_PIN		GPIO_Pin_15
#define SWITCH_PORT		GPIOA
#define SWITCH_CLK		RCC_APB2Periph_GPIOA


#define BUTTON1_PIN		GPIO_Pin_12
#define BUTTON1_PORT		GPIOB
#define BUTTON1_CLK		RCC_APB2Periph_GPIOB

#define BUTTON2_PIN		GPIO_Pin_13
#define BUTTON2_PORT		GPIOB
#define BUTTON2_CLK		RCC_APB2Periph_GPIOB

#define BUTTON3_PIN		GPIO_Pin_14
#define BUTTON3_PORT		GPIOB
#define BUTTON3_CLK		RCC_APB2Periph_GPIOB

#define HIGH_STATE		1
#define LOW_STATE		0

#define SWITCH_MASK			0x01
#define BUTTON1_MASK		0x02
#define BUTTON2_MASK		0x04
#define BUTTON3_MASK		0x08

void InputInitController(void);
void InputService(void);
uint8_t GetSwitchModeValue(void);
uint8_t PressUP(void);
uint8_t PressDOWN(void);
uint8_t PressSELECT(void);

#endif


