#ifndef _ULTILITY_H
#define _ULTILITY_H

#include "stm32f10x.h"
#include <stdio.h>
#include "main.h"

uint8_t GetFirstPositionCharOccur(uint8_t* _str,uint8_t _char);
uint8_t GetLastPositionCharOccur(uint8_t* _str,uint8_t _char);
uint8_t GetIndexString(uint8_t* _source,uint8_t* _sample);
uint8_t GetIndexAfterString(uint8_t* _source,uint8_t* _sample);

uint16_t CRC16Update(uint16_t crc, uint8_t data);
uint16_t CalculateCRC16(uint8_t *data, uint8_t len);
uint8_t FindNumber(uint8_t* source, uint8_t sourceLength,uint8_t value);
#endif

