#ifndef _APPLICATION_H
#define _APPLICATION_H

#include "main.h"

#define MAIN_BACKUP_MODE		0
#define MAIN_PC_MODE			1
#define MAIN_STANDBY_MODE		2
#define MAIN_ENCRYPTION			3

#define MAX_ROOM			60

#define BUFFER_LENGTH		50
#define COMMAND_LENGTH		13

#define DATA_LENGTH_DEFAULT 2

#define HEADER_DLE		0x10
#define HEADER_STX		0x02

#define FOOTER_DLE		0x10
#define FOOTER_ETX		0x03

#define ADD0	CHITHUY		
#define ADD1	TIENGIANG1	
#define ADD2	BROADCAST	

#define CHITHUY		0x80
#define TIENGIANG1	0x01
#define BROADCAST	0x00

#define CMD_TURNON		0x81
#define CMD_TURNOFF		0x82
#define CMD_GETSTATUS	0x83
#define CMD_CONFIG		0x84
#define CMD_HANDSHAKE_PCTOMAIN				0x70
#define CMD_HANDSHAKE_MAIN_RESPONSE		0x71
#define CMD_HANDSHAKE_PC_AUTHENTICATE		0x72
#define CMD_HANDSHAKE_MAIN_AUTHENTICATE	0x73
#define CMD_HANDSHAKE_ERROR				0x74
#define AIRCONDITION_MASK	0x01
#define SOUNDSYSTEM_MASK	0x02	  

#define HEADER_DLE_STATE 		0
#define HEADER_STX_STATE 		1
#define ADDRESS0_STATE		2
#define ADDRESS1_STATE		3
#define ADDRESS2_STATE		4
#define COMMAND_STATE		5
#define DATALENGTH_STATE		6
#define DATA0_STATE			7
#define DATA1_STATE			8
#define GETCRC_HIGH_STATE		9
#define GETCRC_LOW_STATE		10
#define CHECKCRC_STATE		11	
#define FOOTER_DLE_STATE 		12
#define FOOTER_ETX_STATE 		13

#define COMMAND_STATUS_SUCCESS			1
#define COMMAND_STATUS_CRCFAIL			2
#define COMMAND_STATUS_ERROR			0xF0

#define PRIVATE_KEY	"CB4U"

#define ADDRESS0_INDEX		2
#define ADDRESS1_INDEX		3
#define ADDRESS2_INDEX		4
#define COMMAND_INDEX		5
#define LENGTH_INDEX			6
#define DATA0_INDEX			7
#define DATA1_INDEX			8


#define	FIRST_PRESS				0
#define	UP_TIMER_PRESS			1
#define	DOWN_TIMER_PRESS		2	
#define 	SELECT_TIMER_PRESS		3
#define	UP_SHORT_PRESS			4	 
#define	UP_LONG_PRESS			5		 
#define	DOWN_SHORT_PRESS		6				 
#define	DOWN_LONG_PRESS		7
#define 	SELECT_SHORT_PRESS		8
#define 	SELECT_LONG_PRESS		9

#define MANUAL_MODE		0
#define AUTO_MODE		1

#define DEVICE_OFF		0
#define DEVICE_ON			1
typedef struct {
	uint8_t Address[3];	
	uint8_t Command;
	uint8_t DataLength;
	uint8_t Data[2];
}Command_Typedef;


uint16_t CRC16Update(uint16_t crc, uint8_t data);
uint16_t CalculateCRC16(uint8_t *data, uint8_t len);

void ApplicationInit(void);
void ApplicationRunning(void);
void PCAuthenticate(void);
void ButtonProcess(void);
void SystemBackupMode(void);
void SystemPCMode(void);
void SystemStandbyMode(void);
void ResetPCDataReceive(void);

void GetDataFromRS485(void);
void SetMaxSubNode(uint8_t value);
uint8_t GetMaxSubNode(void);
int32_t STM32_MD5_HASH_DigestCompute(uint8_t* InputMessage,
                               uint32_t InputMessageLength,
                               uint8_t *MessageDigest,
                               int32_t* MessageDigestLength);	
void MainResponseHash(uint8_t* pckey);
void CreatTheRandomNumber(void);
uint16_t GetTheRandomNumber(void);
void MainCreateHash(uint16_t mainKey,uint8_t* OutputMessage);
void MainResponseSuccess(void);
void MainResponseFail(void);
void MainResponseNotAuthenticate(uint8_t _cmd);
void MainResponse(uint8_t _cmd);
void MainResponseError(uint8_t _cmd);


void DisplayControlRoomManualMode(uint8_t _room, uint8_t _state);
void SendDataToSubNodeManualMode(uint8_t _room, uint8_t _state);
#endif

