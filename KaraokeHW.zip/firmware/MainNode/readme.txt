﻿Các chế độ hoạt động:
1. PC Mode
	- Nhận lệnh từ PC theo cấu trúc đã thống nhất trên wiki.
	http://wiki.combros.vn/index.php?title=Karaoke_System_-_Protocol
2. Backup Mode : Gồm có 2 chế độ MANUAL và AUTO
	MANUAL sử dụng 3 nút nhấn để điều khiển mạch MAIN yêu cầu SUB bật/tắt thiết bị.
	AUTO thì tự động sau 2 giây MAIN sẽ lần lượt gửi tín hiệu yêu cầu từng Sub bật thiết bị.
	+ Manual Mode:
		- Nhấn nút UP hoặc DOWN để tăng/ giảm phòng muốn điều khiển. Nếu nhấn giữ nút trong 2 giây thì chỉ số phòng sẽ tăng/ giảm 10, còn không thì tăng/ giảm 1.
		- Nhấn nút SELECT để bật/tắt subnode
		- Nếu nhấn giữ nút SELECT 2 giây sẽ có tiếp bip bip 2 lần, khi đó sẽ chuyển sang mode AUTO
	+ Auto Mode:
		- Cứ sau 2 giây, MAIN sẽ lần lượt gửi tín hiệu yêu cầu từng Sub bật thiết bị.
		- Nếu bấm nút SELECT thì sẽ về lại mode MANUAL.